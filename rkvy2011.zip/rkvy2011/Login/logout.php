<?php
	//Start session
	session_start();
	//Unset the variables stored in session
	unset($_SESSION['member_id']);
	unset($_SESSION['firstname']);
	unset($_SESSION['lastname']);
	//header("location: login.php");
	echo "<script language='javascript'> window.location.href='login.php'</script>";
?>
