<html>
<head>
<script type="text/javascript">
function redirect()
{
	document.location.href="manage_user.php";
}
</script>
</head>
<body background="../Include/Img/background.gif" style="background-size:cover;" bgcolor="#0099ff">
<?php
	//Start session
require_once '../Include/auth.php';
require_once '../Include/connect.php';
require_once '../Include/header.php';
$flag=0;
echo "<center><h1><u>ENTER REGISTRATION DETAILS</u></h></center>";
echo "<form method='post' action='register.php'>";
echo "<br><br><table background='../Include/Img/table1.gif' align='center'>";
echo "<tr><td><b>First Name</td><td><input type='text' name='firstname' value=''></b></td></tr>";
echo "<tr><td><b>Last Name Name</td><td><input type='text' name='lastname' value=''></b><img src='../Include/Img/optional.gif'></td></tr>";
echo "<tr><td><b>Login Id</td><td><input type='text' name='login' value=''></td></b></tr>";
echo "<tr><td><b>Password</td><td><input type='password' name='passwd' value=''></b></td></tr>";
echo "<tr><td><b>Retype Password</td><td><input type='password' name='passwd1' value=''></b></td></tr>";
echo "</table><br>";
echo "<center><input type='submit' name='submitted' value='Register'>&nbsp;&nbsp;&nbsp;<input type='button' name='close' value='Close' onclick='redirect();'></center>";
echo "</form>";
if(isset($_POST['submitted'])&&isset($_POST['firstname'])&&isset($_POST['login'])&&isset($_POST['passwd'])&&isset($_POST['passwd1']))
{
	$firstname = $_POST[firstname];
	$lastname = $_POST[lastname];
	if(strlen($_POST[login])>=5)
	{
		$login = $_POST[login];
		$l=1; //if login id is atleast 5 character
	}
	else 
	{
	 echo "<b><center style='color: red;'>Login Id must be atleast 5 character long !</center></b>";
	 $l=0;
	}
	if(    (strlen($_POST[passwd])>=6)   ||    (strlen($_POST[passwd1])>=6)   )
	{
		$plen=1; //if password is atleast 6 char
	}
	else
	{ 
	echo "<b><center style='color: red;'>Password must be atleast 6 character long !</center></b>";
		$plen=0;
	}
	$p=strcmp($_POST[passwd],$_POST[passwd1]);
	if(   ($p==0)) //if both passwords are same
	{
	$passwd = $_POST[passwd];
	}
	else 
	 echo "<b><center style='color: red;'>Both password are not same !</center></b>";
	
	if(($l==1)&&($p==0)&&($plen==1)) //checking duplicate id
	{
		$q = "SELECT * FROM members WHERE login='$login'";
		$r = mysql_query($q,$link);
		if($r) 
		{
			if(mysql_num_rows($r) > 0) 
			{
				echo "<b><center style='color: red;'>Already exist please select an another login name !</center></b>";
			}
			else 
			{
		  		$q1= "INSERT INTO members(firstname, lastname, login, passwd, reg_date) VALUES('$firstname','$lastname','$login',md5('$passwd'),NOW())";
	  			$r1= mysql_query($q1,$link);
	  			if($r1)
					$flag=1;
			}
		}
	}

if($flag==1)
{
echo "<b><center style='color: #003300;'><h2>Successfully Registered with Login Id : $login !</h2></center></b>";
}
}			
?>
</body>
</html>