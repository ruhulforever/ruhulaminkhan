<html>
<head>
<script type="text/javascript">
function redirect()
{
	document.location.href="../Login/manage_user.php";
}
</script>
</head>
<body  bgcolor="#0099ff">
<?php 
require_once '../Include/auth.php';
echo "<div style='color: #003300;' align='center'><b><h2><u>RKVY WEBSITE ADMINISTRATION</u></h2></b></div>";
echo "<center><input type='button' name='close' value='Close' onclick='redirect();'></center>";
echo "<h3><b><center style='color: red;'>THREAT MONITORING LOG !</center></b></h3>";
echo "<table align='center' border='2' bgcolor='silver' width='80%'>";
include  '../Login/trace.txt';
echo "</table>";
?>
</body>
</html>