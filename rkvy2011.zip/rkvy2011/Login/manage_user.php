<html>
<head>
<script language="javascript">
function delete_user(id)
{
    op=confirm("Are you sure to delete this user?");
    if(op)document.location.href="delete.php?id="+id;
      
}
</script>
</head>
<body background="../Include/Img/background.gif" style="background-size:cover;" bgcolor="#0099ff">
<?php
	//Start session
require_once '../Include/auth.php';
require_once '../Include/connect.php';
require_once '../Include/header.php';
$firstname=$_SESSION['firstname'];
$lastname=$_SESSION['lastname'];
$q="SELECT * from members";
$r=mysql_query($q,$link);
$rec=mysql_num_rows($r); //showing total no of users
$rec--; //one decremented 
echo "<div style='color: #003300;' align='center'><b><h2><u>RKVY WEBSITE ADMINISTRATION</u></h2></b></div>";
echo "<br><center><b><a href='view_log.php'><MARQUEE style='color: red;' WIDTH='50%' behavior='alternate' direction='right' scrollamount='10' >Click me for monitoring threat !</MARQUEE></a></font></b></center><br>";
echo "<div style='color: #003300;' align='right'><b><a href='logout.php'>Logout</a></b></div>";
echo "<div style='color: #003300;'><b><a href='../Login/register.php'>Create user</a></b></div><div style='color: #003300;' align='right'><a href='../Login/c_password.php'>Change Admin Password</a></b></div>";
$display=5;
if(isset($_GET['p'])&&is_numeric($_GET['p']))
{
	$pages=$_GET['p'];
}
else 
{
	$q="SELECT * from members";
    $r=mysql_query($q,$link);
	$records=mysql_num_rows($r);
	if($records>$display)
	{
		$pages=ceil($records/$display);
	}
	else 
	{
		$pages=1;	
	}
}
if(isset($_GET['s'])&&is_numeric($_GET['s']))
{
	$start=$_GET['s'];
}
else 
{
	$start=0;
}
$q="select * from members where member_id!=1 limit $start, $display";
$r=mysql_query($q,$link);
$num=mysql_num_rows($r);
if($num>0)
{
 echo "<center><b>There are currently $rec registered users.</b></center><br>";
 echo '<table background="../Include/Img/table1.gif" align="center" border="2" bgcolor="silver" width="75%">
<tr>
<td align="center"><b>Delete</b></td>
<td align="left"><b>First Name</b></td>
<td align="left"><b>Last Name</b></td>
<td align="left"><b>Login Id</b></td>
<td align="center"><b>Registration Date</b></td>
</tr>';
while ($row=mysql_fetch_array($r))
{
echo '<tr>
<td align="center"><a href="Javascript:delete_user('.$row['member_id'].')"><img src="../Include/Img/delete.gif"/></a></td>
<td align="left">&nbsp;'.$row['firstname'].'</td>
<td align="left">&nbsp;'.$row['lastname'].'</td>
<td align="left">&nbsp;'.$row['login'].'</td>
<td align="center">&nbsp;'.$row['reg_date'].'</td>';
}
echo '</table>';
mysql_free_result($r);
}
else
echo '<p>There are currently no registered users.</p>';
if($pages>1)
{
	echo "<br><table align='center'>";
	$current_page=($start/$display)+1;
	if($current_page!=1)
	{
		$prev=$start-$display;
		echo "<tr><td><b><a href='manage_user.php?s=$prev&p=$pages'>Previous</a></b></td>";
	}
	for($i=1;$i<=$pages;$i++)
	{
		if($i!=$current_page)
		{    
			$d=$display*($i-1);
			//echo "<td><a href='manage_user.php?s=$d&p=$pages'>$i</a></td>";
		}
		else 
		{
			echo "<td><b>$i</b></td>";
		}
	}
	if($current_page!=$pages)
	{
		$n=$start+$display;
		echo "<td><b><a href='manage_user.php?s=$n&p=$pages'>Next</a></b></td></tr>";
	}
	echo "</table>";
}
?>
</body>
</html>