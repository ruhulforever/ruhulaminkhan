<html>
<head>
<script type="text/javascript">
function redirect()
{
	document.location.href="../Home/home.php";
}
</script>
</head>
<body background="../Include/Img/background.gif" style="background-size:cover;" bgcolor="#0099ff">
<?php
	//Start session
require_once '../Include/auth.php';
require_once '../Include/connect.php';
require_once '../Include/header.php';
$flag=0;
function clean($str) //Function to sanitize values received from the form. Prevents SQL injection
	{
		$str = @trim($str);
		if(get_magic_quotes_gpc()) 
		{
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
echo "<form method='post' action='c_password.php'>";
echo "<br><br><table background='../Include/Img/table1.gif' align='center'>";
echo "<tr><td><b>Current Password</td><td><input type='password' name='cpasswd' value=''></b></td></tr>";
echo "<tr><td><b>New Password </td><td><input type='password' name='npasswd' value=''></b><img src='../Include/Img/optional.gif'></td></tr>";
echo "<tr><td><b>Retype New Password</td><td><input type='password' name='npasswd1' value=''></td></b></tr>";
echo "</table><br><br>";
echo "<center><input type='submit' name='submitted' value='Save'>&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' name='cancel' value='Cancel' onclick='redirect();'></center>";
echo "</form>";
if(isset($_POST['submitted'])&&isset($_POST['cpasswd'])&&isset($_POST['npasswd'])&&isset($_POST['npasswd1']))
{
	$cpasswd = clean($_POST['cpasswd']); //calling to sanitize post value
	$npasswd = clean($_POST['npasswd']);  //calling to sanitize post value
	$npasswd1 = clean($_POST['npasswd1']);  //calling to sanitize post value
	$member_id = $_SESSION['member_id'];
	if(    (strlen($_POST[npasswd])>=6)   ||    (strlen($_POST[npasswd1])>=6)   )
	{
		$plen=1; //if password is atleast 6 char
	}
	else
	{ 
	echo "<b><center style='color: red;'>Password must be atleast 6 character long !</center></b>";
		$plen=0;
	}
	$p=strcmp($_POST[npasswd],$_POST[npasswd1]);
	if(   ($p==0)) //if both passwords are same
	{
	$passwd = $_POST[passwd];
	}
	else 
	 echo "<b><center style='color: red;'>Both New passwords are not same !</center></b>";
	if(($p==0)&&($plen==1))
	{
	$q="SELECT * FROM members WHERE member_id=$member_id AND passwd = md5('$cpasswd')";
	$r=mysql_query($q,$link);
		if($r) //Check whether the query was successful or not
		{
			if(mysql_num_rows($r) == 1) 
			{
				$q1="update members set passwd=md5('$npasswd') where member_id=$member_id limit 1";
				$r1=mysql_query($q1,$link);
				if($r1)
				{
					unset($_SESSION['member_id']);
					unset($_SESSION['firstname']);
					unset($_SESSION['lastname']);
					$flag=1;
				}
			}
		}
	}
}
if($flag==1)
{
	echo "<b><center style='color: #003300;'><h2>Password Successfully Changed !</h2></center></b>";
	echo "<b><center style='color: #003300;'><h3><a href='login.php'>Click Here to Login</a></h3></center></b>";
}
?>
</body>
</html>