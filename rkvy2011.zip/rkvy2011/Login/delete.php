<?php
require_once '../Include/auth.php';
require_once('../Include/connect.php');
if( (isset($_GET['id'])) && (is_numeric($_GET['id'])) )
{
$id=$_GET['id'];
$q="DELETE FROM members WHERE member_id=$id LIMIT 1";
$r=mysql_query($q,$link);
if(mysql_affected_rows($link)==1)
	//header("location: manage_user.php");
	echo "<script language='javascript'> window.location.href='manage_user.php'</script>";
}
else
	echo '<p> Error accessed !</p>';
?>




