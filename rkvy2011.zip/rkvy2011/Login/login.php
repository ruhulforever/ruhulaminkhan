<html>
<head>
<title>RKVY WBIS Sentry</title>
<link href="../Include/button.css" rel="StyleSheet" type="text/css">
</head>
<body background="../Include/Img/background.gif" style="background-size:cover;" bgcolor="#0099ff">
<?php
	//Start session
	
	@session_start();
	require_once '../Include/connect.php';
	require_once '../Include/header.php';
	function clean($str) //Function to sanitize values received from the form. Prevents SQL injection
	{
		$str = @trim($str);
		if(get_magic_quotes_gpc()) 
		{
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
//$str = 'ruhul';
//$str1=base64_encode($str);
//$str2=base64_decode($str1);
//echo "This is the encoding of ruhul >>>>>> $str1<br>";
//$str = 'VGhpcyBpcyBhbiBlbmNvZGVkIHN0cmluZw==';
//echo "This is the decoding of ruhul >>>>> $str2";
echo "<center><img src='../Include/Img/title.gif' style='opacity:0.9;' alt='OFFICE OF THE EXECUTIVE ENGINEER (AGRI), SONITPUR ASSAM'/></center>";
echo "<form method='post' action='login.php'>";
echo "<br><br><table background='../Include/Img/table1.gif' align='center'>";
echo "<tr><td><b>Login Id</td><td><input type='text' name='login' value=''></td></b></tr>";
echo "<tr><td><b>Password</td><td><input type='password' name='passwd' value=''></b></td></tr>";
echo "</table><br><br>";
echo "<center><input id='login' type='submit' name='submitted' value=''></center>";
echo "</form>";
$ip=$_SERVER['REMOTE_ADDR'];
$hostname=gethostbyaddr($ip);
$time_now=mktime(date('h')+5,date('i')+30,date('s'));
$time=date('h:i:s',$time_now);
$date=date("F j,Y");
if(isset($_POST['submitted'])&&isset($_POST['login'])&&isset($_POST['passwd']))
{
	$login = clean($_POST['login']); //calling to sanitize post value
	$passwd = clean($_POST['passwd']);  //calling to sanitize post value
	////////////////
	$log= "<tr><td><u>Date</u></td><td> $date</td> <td><u>Time</u> <td><td> $time</td><td><u>IP Adrees</u></td><td> $ip </td><td> <u>Computer Name</u></td><td> $hostname</td> <td><u>Login Id</u></td><td>$login</td><tr>"; 
	$fd = @fopen( '../Login/trace.txt', "a" );
	@fwrite( $fd, $log );
	@fclose( $fd );
	////////////////////
	$q="SELECT * FROM members WHERE login='$login' AND passwd = md5('$passwd')";
	$r=mysql_query($q,$link);
	if($r) //Check whether the query was successful or not
	{
		if(mysql_num_rows($r) == 1) 
		{
			@session_regenerate_id();
			$member = mysql_fetch_array($r);
			$_SESSION['member_id'] = $member['member_id'];
			$_SESSION['firstname'] = $member['firstname'];
			$_SESSION['lastname'] = $member['lastname'];
			@session_write_close();
			if($member['member_id']==1)
			{
			 echo "<script language='javascript'> window.location.href='../Login/manage_user.php'</script>";
			}
			else
			echo "<script language='javascript'> window.location.href='../Home/home.php'</script>";
		}
		else 
		{
			echo "<h3><b><center style='color: red;'>Login Failed !</center></b></h3>";
			 
		}
	}
	else 
	{
		die("Query failed");
	}
}
?>
</body>
</html>