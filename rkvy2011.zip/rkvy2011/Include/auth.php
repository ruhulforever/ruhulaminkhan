<?php
	//Start session
	session_start();
	
	//Check whether the session variable session variable  is present or not
	if(!isset($_SESSION['member_id']) || (trim($_SESSION['member_id']) == '')) {
		//header("location: ../Login/login.php");
		echo "<script language='javascript'> window.location.href='../Login/login.php'</script>";
		exit();
	}
?>