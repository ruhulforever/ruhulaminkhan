<table background="../Include/Img/table.gif" bgcolor="#3399CC" cellspacing="0" width="100%" height="50">
<TR><TD><h4>&nbsp;RKVY2011</h4><small>&nbsp;&nbsp;&nbsp;Information System For Rastriya Krishi Vikash Yojana<br>&nbsp;&nbsp;&nbsp;&copy; 2011 Developed for Mca Final Semester Project</small><br><br></TD><TD align="right" valign="bottom"><?php echo date("F j,Y"); ?></TD></TR>
</table><br> 
