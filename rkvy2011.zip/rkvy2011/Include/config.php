<?php
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASSWORD','ruhul');
define('DB_DATABASE','rkvy2011');
?>
