function validate(frm)
{
	var i=0;
	if(frm.group_id.value=="")
    {
	   alert("Applicant category not selected!");
	   return false;
	}
	if(frm.group_id.value==1)
	{
		
		if(frm.applicant_name.value=="")
		{
			alert("Farmer's Name missing !");
		}
		
	}
	if(frm.group_id.value==2||frm.group_id.value==3)
	{
		if(frm.group_name.value=="")
			alert("Group name missing !");
		if(frm.n_o_group.value=="")
			alert("Not mentioned no. of group member !");
	}
	if(frm.d_o_e.value=="")
	{
		alert("Date of Entry Missing !");
		return false;
	}
	if(frm.n_o_m.value=="")
	{
		alert("Name of Machinery missing !");
		return false;
	}
	if(frm.gp.value=="")
	{
		alert("GP name missing !");
		return false;
	}
	if(frm.ap.value=="")
	{
		alert("AP name missing !");
		return false;
	}
	if(frm.zp.value=="")
	{
		alert("ZP name missing !");
		return false;
	}
	if(frm.block.value=="")
	{
		alert("Block name missing !");
		return false;
	}
	if(frm.ph_no.value=="")
	{
		alert("Phone/Record No. missing !");
		return false;
	}
    if(frm.n_o_m_o.value=="")
    {
        alert("No of machinery obtained missing !");
        return false;
    }
    if(frm.t_land.value=="")
    {
        alert("Total Land not mentioned !");
        return false;
    }
    if(frm.c_land.value=="")
    {
        alert("Cultivable Land not mentioned !");
        return false;
    }
    if(frm.w_c_f_s.value=="")
    {
        alert("Willingness to contribute farmer's share not mentioned !");
        return false;
    }
    if(frm.is_defaulter.value=="")
    {
        alert("Wheathe any member is defaulter is not mentioned !");
        return false;
    }
    if(frm.i_f.value=="")
    {
        alert("Irrigation facilities is not mentioned !");
        return false;
    }
    if(frm.w_section.value=="")
    {
        alert("Presence of weaker section is not mentioned !");
        return false;
    }
    if(frm.n_o_w_f.value=="")
    {
        alert("No. of women farmer is not mentioned !");
        return false;
    }
    if(frm.f_used.value=="")
    {
        alert("Use of fertilizer is not mentioned !");
        return false;
    }
    if(frm.c_intensity.value=="")
    {
        alert("Cropping Intensity is not mentioned !");
        return false;
    }
}






