<table  bgcolor="#0066ff" cellspacing="0" width="100%" height="10">
<TR><TD align="center"><small>2011 &copy; Develped For MCA Final Semester Project</small></TD></TR>
</table>
