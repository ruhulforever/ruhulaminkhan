function license()
{
	 alert("Project Assigned :\n" +
		  "\t To develop an Information System for managing the\n" +
		  "\t installation of 2000 nos. of S.T.W and 500 nos. of\n " +
		  "\t L.L.P in Sonitpur Dist. under R.K.V.Y. 2010-11.\n\n" +
		  "Implementing Agency :\n" +
		  "\t Executive Engineer (Agri), Tezpur Division, Assam.\n\n" +
		  "Initiated and Authorized By :\n" +
		  "\t Sri. Partha Pratim Handique.\n" +
		  "\t Asst. Executive Engineer (Agri),\n" +
		  "\t Tezpur Division, Sonitpur Assam.\n\n" +
		  "With Cordial thanks to :\n" +
		  "\t Sri. Prantor Bhagawati (Asstt. Agril. Engineer).\n" +
		  "\t Sri. Iftikar Rahman (J.E.) \n" +
		  "\t Tezpur Division, Sonitpur Assam.\n\n" +
		  "Developed By	:\n" +
		  "\t Sri. Ruhul Amin Khan.\n" +
		  "\t MCA Final Semester, SMU\n" +
		  "\t Email: ruhulforever@gmail.com ");
}