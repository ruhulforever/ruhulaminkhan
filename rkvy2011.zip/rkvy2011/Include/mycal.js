Rico.loadModule('Calendar','ColorPicker');
var cal,c;
Rico.onLoad( function() {

  // initialize calendar  (addHoliday calls are optional)
  cal=new Rico.CalendarControl("cal");
  cal.addHoliday(25,12,0,'Christmas','#F55','white');
  cal.addHoliday(1,1,0,'New Years','#2F2','white');
  cal.atLoad();
  cal.returnValue=function(newVal) { $('CalendarValue').value=newVal; };
  
  ////////////////////////////////////
  c=new Rico.CalendarControl("c");
  c.addHoliday(25,12,0,'Christmas','#F55','white');
  c.addHoliday(1,1,0,'New Years','#2F2','white');
  c.atLoad();
  c.returnValue=function(newVal) { $('CalendarValue1').value=newVal; };
  
  /////////////////////////////////////////
  c1=new Rico.CalendarControl("c1");
  c1.addHoliday(25,12,0,'Christmas','#F55','white');
  c1.addHoliday(1,1,0,'New Years','#2F2','white');
  c1.atLoad();
  c1.returnValue=function(newVal) { $('CalendarValue2').value=newVal; };
  ////////////////////////////////////////
  c2=new Rico.CalendarControl("c2");
  c2.addHoliday(25,12,0,'Christmas','#F55','white');
  c2.addHoliday(1,1,0,'New Years','#2F2','white');
  c2.atLoad();
  c2.returnValue=function(newVal) { $('CalendarValue3').value=newVal; };

  
  // initialize color picker
  colorpicker=new Rico.ColorPicker("colorpicker1");
  colorpicker.atLoad();
  colorpicker.returnValue=ProcessColorSelection;
  colorBox=$('ColorValue');
});
function CalendarClick(e) {
  if (Element.visible(cal.container)) {
    cal.close();
  } else {
    RicoUtil.positionCtlOverIcon(cal.container,$('CalendarButton'));
    cal.open();
    c.close();
    colorpicker.close();
  }
  Event.stop(e);
}
function calendar(e) {
	  if (Element.visible(cal.container)) {
	    c.close();
	  } else {
	    RicoUtil.positionCtlOverIcon(c.container,$('CalendarButton1'));
	    c.open();
	    colorpicker.close();
	  }
	  Event.stop(e);
	}
function calendar1(e) {
	  if (Element.visible(cal.container)) {
	    c1.close();
	  } else {
	    RicoUtil.positionCtlOverIcon(c1.container,$('CalendarButton2'));
	    c1.open();
	    colorpicker.close();
	  }
	  Event.stop(e);
	}
function calendar2(e) {
	  if (Element.visible(cal.container)) {
	    c2.close();
	  } else {
	    RicoUtil.positionCtlOverIcon(c2.container,$('CalendarButton3'));
	    c2.open();
	    colorpicker.close();
	  }
	  Event.stop(e);
	}