<?php

/**
 * @author 
 * @copyright 2011
 */
require_once '../Include/auth.php';
require_once('../Include/connect.php');
if(is_numeric($_GET['applicant_id'])&&is_numeric($_GET['id']))
{
    $kid=$_GET['applicant_id']; //storing applicant_id, to send again to the calling page using query string
    $id=$_GET['id'];
    $q="DELETE FROM pump_cost WHERE id=$id LIMIT 1"; ///////////////////////////////////////////
	$r=mysql_query($q,$link);
    if($r) {
		//header("location: c_o_p.php?applicant_id=$kid"); /////////////////////////////////////
		echo "<script language='javascript'> window.location.href='c_o_p.php?applicant_id=$kid'</script>";
		exit();
	}else {
		die("Query failed");
	}
}
else 
{
    echo "<h1><center>Error Accessed !</center></h1>";
}

?>