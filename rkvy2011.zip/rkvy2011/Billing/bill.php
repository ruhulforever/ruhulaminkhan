<html>
<head>
<link href="../Include/button.css" rel="StyleSheet" type="text/css">
<script language="javascript">
</script>
</head>
<body background="../Include/Img/background.gif" style="background-size:cover;" bgcolor="#0099ff">
</body></html>
<?php
require_once '../Include/auth.php';
require_once '../Include/connect.php';
require_once '../Include/header.php';
/**
 * @author 
 * @copyright 2011
 */
if(isset($_GET['applicant_id'])&&is_numeric($_GET['applicant_id']))
{
    $applicant_id=$_GET['applicant_id'];
    $q="select * from applicant where applicant_id=$applicant_id";
	$r=mysql_query($q,$link);
	if($r)
    {
    $row=mysql_fetch_array($r);
    $group_id=$row['group_id'];
	$applicant_name=$row['applicant_name'];
	$group_name=$row['group_name'];
	echo '<h1><center><b><u>RKVY AUTO BILLING FOR A.S.G/S.H.G/Individual</u></b></center></h1>';
	if($group_id==1)
    echo '<h3><center><b>Current Bill for '.$row['applicant_name'].' (Individual)</b></center></h3>';
    if($group_id==2)
    echo '<h3><center><b>Current Bill for '.$row['group_name'].' (S.H.G)</b></center></h3>';
    if($group_id==3)
    echo '<h3><center><b>Current Bill for '.$row['group_name'].' (A.S.G)</b></center></h3>';
    } 
    echo '<center><b><a href="c_o_m.php?applicant_id='.$applicant_id.'">Cost of Material<img src="../Include/Img/direction.gif"></a>
                     <a href="c_o_i.php?applicant_id='.$applicant_id.'">Cost of Installation<img src="../Include/Img/direction.gif"></a>
                     <a href="c_o_p.php?applicant_id='.$applicant_id.'">Cost of Pump Set<img src="../Include/Img/direction.gif"></a>
                     <a href="summarize.php?applicant_id='.$applicant_id.'">Summarize<img src="../Include/Img/direction.gif"></a>
                     <a href="report.php?applicant_id='.$applicant_id.'">View & Print</a>
                 </b></center>';
    $q="select * from sum_cost where applicant_id='$applicant_id'";
    $result=mysql_query($q,$link);
    if($result)
    {
        $row=mysql_fetch_array($result);
        $deposited=$row['fs']-($row['mat_cost']+$row['install_cost']);
        echo "<table align='center'>";
        echo "<tr><td><b>Cost of Material</td><td><input type='text' name='c_o_m' value='$row[mat_cost]'></td></tr><br>";
        echo "<tr><td><b>Cost of Installation</td><td><input type='text' name='c_o_i' value='$row[install_cost]'></td></tr><br>";
        echo "<tr><td><b>Cost of Pump Set</td><td><input type='text' name='c_o_p' value='$row[pump_cost]'></td></tr><br>";
        echo "<tr><td><b>Total Cost of S.T.W</td><td><input type='text' name='tc' value='$row[tc]'></td></tr><br>";
        echo "<tr><td><b>Govt. Subsidy</td><td><input type='text' name='gs' value='$row[gs]'></td></tr><br>";
        echo "<tr><td><b>Farmer's Share</td><td><input type='text' name='fs' value='$row[fs]'></td></tr><br>";
        echo "<tr><td><b>Farmer's Share to be deposited</td><td><input type='text' name='fsd' value='$deposited'></td></tr><br>";
        echo "</table>";
    	if($row['gs']>20400)
        {
        	echo "<center><h2 style='color: red;'>Exceeding permissible Govt. Subsidy i.e 20,400/-  !</h2></center>";
        }
        echo "<br><br><tr><center><input id='close' type='button'  value='' 
              onclick='window.close();'></center></tr><br>";
               
    }
    
}
else
{
    echo "<p><center><b>Error Accessed!</b></center></p>";
}
?>