<html>
<head>
<link href="../Include/button.css" rel="StyleSheet" type="text/css">
<script language="javascript">
function calculate(form,applicant_id)
{
    var val=form.percent.options[form.percent.options.selectedIndex].value;
    self.location='summarize.php?applicant_id='+applicant_id+'&p='+val;
}
function redirect(applicant_id)
{
    document.location.href='bill.php?applicant_id='+applicant_id;
 }
 function exceedtest(gs)
 {
	 if(gs>20400)
	 {
		 alert("gs");
	 }
 }
</script>
</head>
<body background="../Include/Img/background.gif" style="background-size:cover;" bgcolor="#0099ff"></body>
</html>
<?php
require_once '../Include/auth.php';
require_once('../Include/connect.php');
require_once '../Include/header.php';
if(isset($_GET['applicant_id'])&&is_numeric($_GET['applicant_id']))
{
   //calculating total cost 
   $applicant_id=$_GET['applicant_id'];
   $q="select mat_cost,install_cost,pump_cost from sum_cost where applicant_id=$applicant_id";
   $result=mysql_query($q,$link);
   $row=mysql_fetch_array($result);
   $tc=$row['mat_cost']+$row['install_cost']+$row['pump_cost'];
   $q="update sum_cost set tc=$tc where applicant_id=$applicant_id";
   $result=mysql_query($q,$link);
}
echo "<br><br><br>";
echo "<form>";
echo "<b>Total Cost of S.T.W   </b>";
echo "<input type='text' name='tc' value='$tc'>";
$series=range(0,100);
echo "<b>  Govt. Subsidy    </b>";
echo "<select name='percent' onchange=\"calculate(this.form,$applicant_id)\">
      <option value=''>Select</option>";
      foreach($series as $value)
      {
        echo "<option value=\"$value\">$value</option>\n";
      }
      if(isset($_GET['p'])&&is_numeric($_GET['p']))
      {
        echo "<option selected value=\"$value\">$_GET[p]</option>";
      }
echo "</select><b> % </b><b>=</b>  ";
if(isset($_GET['p'])&&is_numeric($_GET['p']))
{
  $p=$_GET['p'];
  $gs=($tc*$p)/100;
  $fs=$tc-$gs;
  $q="update sum_cost set gs=$gs, fs=$fs where applicant_id=$applicant_id";  
  $result=mysql_query($q,$link);
}
echo "<input type='text' name='gs' value=$gs>";
echo "<b>   Farmer's Share  </b>";
echo "<input type='text' name='fs' value=$fs>";
echo "</form>";
if($gs>20400)
{
  echo "<center><h2 style='color: red;'>Exceeding permissible Govt. Subsidy i.e 20,400/-  !</h2></center>";
  echo "<center><h4 style='color: red;'>Hint : Press Complete to change in previous steps  !</h4></center>";
}
echo '<br><br><br><tr><center>
<td><b><input id="complete" type="button" value="" onclick="redirect('.$applicant_id.')"</b></td>';
echo '</center></tr>';

?>