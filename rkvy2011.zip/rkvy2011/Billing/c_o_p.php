<html>
<head>
<link href="../Include/button.css" rel="StyleSheet" type="text/css">
<script language="javascript">
function reload(kid,form)
{
    var val=form.item.options[form.item.options.selectedIndex].value;
    self.location='c_o_p.php?applicant_id='+kid+'&item_no='+val;
}
function mul(kid,form,keep_i)
{
    var val=form.quantity.options[form.quantity.options.selectedIndex].value;
    self.location='c_o_p.php?applicant_id='+kid+'&item_no='+keep_i+'&qnty='+val;
}
function delete_pump_cost(mat_id,kid)
{
    op=confirm("Are you sure to delete ?");
    if(op)document.location.href='delete_pump_cost.php?applicant_id='+kid+'&id='+mat_id;
      
}
function update(kid)
{
    op=confirm("Are you sure to proceed ?");
    if(op)document.location.href='c_o_p_u.php?applicant_id='+kid;
}
</script>
</head>
<body background="../Include/Img/background.gif" style="background-size:cover;" bgcolor="#0099ff"></body>
</html>
<?php 
require_once '../Include/auth.php';
require_once('../Include/connect.php');
require_once '../Include/header.php';
global $keep_i, $keep_q, $kid; //storing item_no & quantity & applicant_id from query string
if(isset($_GET['applicant_id'])&&is_numeric($_GET['applicant_id']))
{
    $kid=$_GET['applicant_id'];
}
if(isset($_GET['item_no'])&&is_numeric($_GET['item_no']))
{
    $keep_i=$_GET['item_no'];
}
if(isset($_GET['qnty'])&&is_numeric($_GET['qnty']))
{
    $keep_q=$_GET['qnty'];
}
/* Inserting the applicant_id into sum_cost table only once, because applicant_id inside sum_cost
   table is defined as unique. We will use applicant_id to update sum_cost for a particular applicant */
$q="select * from sum_cost where applicant_id=$kid";
$result=mysql_query($q,$link);
$num=mysql_num_rows($result);
if($num==0)
{
    $q="insert into sum_cost(applicant_id) values('$kid')";
    $result=mysql_query($q,$link);
}
/* Updating bill status for the applicant */
$q="update applicant set bill_status=1 where applicant_id=$kid";
$result=mysql_query($q,$link);
echo "<form method='post' action='c_o_p.php?applicant_id=$kid'>"; //////////////
echo "Select Item ";
echo "<select name='item' onchange=\"reload($kid,this.form)\">
<option value=''>Select an Item</option>";
$q="select item_no,brand,model,hp from item_table where cat_id=3 order by item_name";
$result=mysql_query($q,$link);
while($row=mysql_fetch_array($result))
{
    if($row['item_no']==$_GET['item_no'])
    {
        echo "<option selected value='$row[item_no]'>Brand : $row[brand] &nbsp;&nbsp;&nbsp;Model : $row[model]</option>"."<br>";
    }
    else
    {
    echo "<option value='$row[item_no]'>Brand : $row[brand] &nbsp;&nbsp;&nbsp;Model : $row[model]</option>";    
    }
}
echo "</select>";
//displaying price which is depend on the selected item
if(isset($_GET['item_no'])&&is_numeric($_GET['item_no']))
{
    $num=$_GET['item_no'];
    $q="select price from item_table where item_no=$num limit 1";
    $result=mysql_query($q,$link);
    $row=mysql_fetch_array($result);
    echo " Price ";
    echo "<input type='text' name='price' value='$row[price]'>";
    
}
else
{
    echo " Price ";
    echo "<input type='text' name='price' value=''>";
    
}
echo " Quantity ";
$series=range(0,100);
echo "<select name='quantity' onchange=\"mul($kid,this.form,$keep_i)\">
      <option value=''>Select</option>";
      if(isset($_GET['qnty'])&&is_numeric($_GET['qnty']))
      {
        $qq=$_GET['qnty'];
        echo "<option selected value='$qq'>$qq</option>"."<br>";
      }
      else
      {
      foreach($series as $value)
      {
        echo "<option value=\"$value\">$value</option>\n";
      }
      }
      echo "</select>";
      if(isset($_GET['qnty'])&&is_numeric($_GET['qnty']))
      {
        $cal_price=$_GET['qnty']*$row['price'];
        echo "   =";
        echo "<input type='text' align='right' name='amount' value='$cal_price'>";
        echo "  Rs.";
      }
      else
      {
        echo "   =";
        echo "<input type='text' align='right' name='amount' value=''>";
        echo "  Rs.";
      }
echo "<input id='add' type='submit' name='submit' value=''>";
echo "</form>";
if(isset($_POST['submit'])) 
{
    
    if(is_numeric($_POST['item'])&& is_numeric($_POST['price'])&& is_numeric($_POST['quantity'])&& is_numeric($_POST['amount']))
    {
        $item_no=$_POST['item']; //collecting item_no from the self calling form
        $q="select brand,model,hp from item_table where item_no=$item_no limit 1"; //retrieving brand and model
        $result=mysql_query($q,$link);
        $row=mysql_fetch_array($result);
        $item_name="Brand : $row[brand] Model : $row[model] HP : $row[hp]";
        $q="insert into pump_cost (item_name,quantity,rate,amount,applicant_id) values('$item_name','$_POST[quantity]',
            '$_POST[price]','$_POST[amount]','$kid')"; ///////////////
        $r=mysql_query($q,$link);
    }
    
}
//displaying records dynamically from the table pump_cost everytime user add a record ////////////
$q="select * from pump_cost where applicant_id=$kid"; ////////////////
$result=mysql_query($q,$link);
$num=mysql_num_rows($result);
if($num>0)
{
echo '<table align="center" border="4" bgcolor="silver" width="85%">
<tr>
<td align="center"><b>Delete</b></td>
<td align="center"><b>Sl.No.</b></td>
<td align="center"><b>Item Name</b></td>
<td align="center"><b>Quantity</b></td>
<td align="center"><b>Rate</b></td>
<td align="center"><b>Amount</b></td>
</tr>';
$sl_no=0;
while ($row=mysql_fetch_array($result))
{
$sl_no+=1; ///////////////////////////
echo '<tr>
<td align="center"><a id="delete" href="Javascript:delete_pump_cost('.$row['id'].','.$kid.')">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></td>
<td align="center">'.$sl_no.'</td>
<td align="left">'.$row['item_name'].'</td>
<td align="center">'.$row['quantity'].'</td>
<td align="right">'.$row['rate'].'</td>
<td align="right">'.$row['amount'].'</td></tr>';
}
echo '</table>';
echo '<br><tr><center>
<td><input id="complete" type="button" value="" onclick="update('.$kid.')"</td>';
echo '</center></tr>';
mysql_free_result($result);
}


?>