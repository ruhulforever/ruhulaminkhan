<html>
<head>
<title>Bill Info</title>
<link href="../Include/button.css" rel="StyleSheet" type="text/css">
<script src="../Include/Calender/prototype.js" type="text/javascript"></script>
<script src="../Include/Calender/rico.js" type="text/javascript"></script>
<script src="../Include/mycal.js" type="text/javascript"></script>
<script type="text/javascript">
function bill(applicant_id)
{
	document.location.href="bill.php?applicant_id="+applicant_id;
}
function edit(applicant_id)
{
	document.location.href="bill_info.php?applicant_id="+applicant_id;
}
</script>
</head>
<body background="../Include/Img/background.gif" style="background-size:cover;" bgcolor="#0099ff" >
<?php 
require_once '../Include/auth.php';
require_once '../Include/connect.php';
require_once '../Include/header.php';
if(is_numeric($_GET['applicant_id']))
{
	$applicant_id=$_GET['applicant_id'];
	$q="select * from bill_info where applicant_id=$applicant_id";
	$r=mysql_query($q,$link);
	$no=mysql_num_rows($r);
	$row=mysql_fetch_array($r);
	$w_o_n=$row['w_o_n'];
	$w_o_date=$row['w_o_date'];
	$d_o_c=$row['d_o_c'];;
	$depth=$row['depth'];
	$mb_no=$row['mb_no'];
	$page_s=$row['page_s'];
	$page_e=$row['page_e'];
	$v_bill_no=$row['v_bill_no'];
	$d_o_b=$row['d_o_b'];
	$m_s_p=$row['m_s_p'];
	$memo_no=$row['memo_no'];
	$d_o_memo=$row['d_o_memo'];
	$m_s_m=$row['m_s_m'];
    if($no==0)
	{
		$q="insert into bill_info(applicant_id) values('$applicant_id')";
		$r=mysql_query($q,$link);
		//@header("location: bill_info.php?applicant_id=$applicant_id");
		echo "<script language='javascript'> window.location.href='bill_info.php?applicant_id=$applicant_id'</script>";
	}
}
echo "<form method='post' action='bill_info.php?applicant_id=$applicant_id'>";
echo "<table  align='left' width='100%' height='200'>";
        echo "<th align='left'><b><u>ENTER BILL INFORMATION</u></b></th>";
        echo "<tr><td><b>Work Order No.</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;EE/Agri/Tez/T-98/10-11/</td><td><input type='text' name='w_o_n' value='$w_o_n'></td></tr>";
        echo "<tr><td><b>Work Order Date</td><td><input type='text' id='CalendarValue' name='w_o_date' value='$w_o_date'>
        		         <a href=''><img id='CalendarButton' src='../Include/Img/cal.gif' onclick=\"CalendarClick(event)\"></a></td>
              </tr>";
        echo "<tr><td><b>MB No.</td><td><input type='text' name='mb_no' value='$mb_no'></td>
                  <td><b>Page No.</td><td><input type='text' name='page_s' value='$page_s'></td><td><b>To</b></td>
                                      <td><input type='text' name='page_e' value='$page_e'></td></tr>";
        echo "<tr><td><b>Date of Completion of Work</td><td><input type='text' id='CalendarValue1' name='d_o_c' value='$d_o_c'>
        		         <a href=''><img id='CalendarButton1' src='../Include/Img/cal.gif' onclick=\"calendar(event)\"></a></td>
              </tr>";
        echo "<tr><td><b>Depth of Boring</td><td><input type='text' name='depth' value='$depth'></td></tr><tr></tr>";
        echo "<th align='left'><b><u>Materials Information</u></b></th>";
        echo "<tr><td><b>Vide Cash-Memo No.</td><td><input type='text' name='memo_no' value='$memo_no'></td><td><b>dtd</b></td>
                  <td><input type='text' id='CalendarValue2' name='d_o_memo' value='$d_o_memo'>
        		         <a href=''><img id='CalendarButton2' src='../Include/Img/cal.gif' onclick=\"calendar1(event)\"></a></td><td><b>M/S</b></td>
        		  <td><input type='text' name='m_s_m' value='$m_s_m'></td>
              </tr>";
        echo "<th  align='left'><b><u>Pump-Set Information</u></b></th>";
        echo "<tr><td><b>Vide Bill No.</td><td><input type='text' name='v_bill_no' value='$v_bill_no'></td><td><b>dtd</b></td>
                  <td><input type='text' id='CalendarValue3' name='d_o_b' value='$d_o_b'>
        		         <a href=''><img id='CalendarButton3' src='../Include/Img/cal.gif' onclick=\"calendar2(event)\"></a></td><td><b>M/S</b></td>
        		  <td><input type='text' name='m_s_p' value='$m_s_p'></td>
              </tr><tr></tr>";
        echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input id='ok' type='submit' name='submit' value=''></td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input id='close' type='button' name='close' value='' onclick='window.close();'></td>";
                                                                                
     	echo "</tr><br>";
//echo "</table>";
echo "</form><br>";
if(isset($_POST['submit']))
{
	$w_o_n=$_POST[w_o_n];
	$w_o_date=$_POST[w_o_date];
	$d_o_c=$_POST[d_o_c];
	$depth=$_POST[depth];
	$mb_no=$_POST[mb_no];
	$page_s=$_POST[page_s];
	$page_e=$_POST[page_e];
	$v_bill_no=$_POST[v_bill_no];
	$d_o_b=$_POST[d_o_b];
	$m_s_p=$_POST[m_s_p];
	$memo_no=$_POST[memo_no];
	$d_o_memo=$_POST[d_o_memo];
	$m_s_m=$_POST[m_s_m];
	$q1="update bill_info set w_o_n='$w_o_n',w_o_date='$w_o_date',d_o_c='$d_o_c',depth='$depth',mb_no='$mb_no',
	                         page_s='$page_s',page_e='$page_e',v_bill_no='$v_bill_no',d_o_b='$d_o_b',m_s_p='$m_s_p',memo_no='$memo_no',
	                         d_o_memo='$d_o_memo',m_s_m='$m_s_m'
						  where applicant_id=$applicant_id limit 1";
	$r1=mysql_query($q1,$link);
	// displaying inserted data and providing option to edit and delete inserted record
	
	if($r1)
	{
    $applicant_id=$_GET['applicant_id'];
	$q="select * from bill_info where applicant_id=$applicant_id";
	$r=mysql_query($q,$link);
	$no=mysql_num_rows($r);
	$row=mysql_fetch_array($r);
	$w_o_n=$row['w_o_n'];
	$w_o_date=$row['w_o_date'];
	$d_o_c=$row['d_o_c'];;
	$depth=$row['depth'];
	$mb_no=$row['mb_no'];
	$page_s=$row['page_s'];
	$page_e=$row['page_e'];
	$v_bill_no=$row['v_bill_no'];
	$d_o_b=$row['d_o_b'];
	$m_s_p=$row['m_s_p'];
	$memo_no=$row['memo_no'];
	$d_o_memo=$row['d_o_memo'];
	$m_s_m=$row['m_s_m'];
	echo "<br><th><b><u>VERIFY RECORDED INFORMATION</u></b></th>";
    echo "<tr><td><b>Work Order No : </b></td> <td>$w_o_n </td></tr>";
	echo "<tr><td><b>Work Order Date : </b></td><td>$w_o_date</td></tr>";
	echo "<tr><td><b>MB No : </b> </td><td>$mb_no</td><td><b>Page No </b></td><td>$page_s</td><td><b>To</b></td><td>$page_e</td></tr>";
	echo "<tr><td><b>Date of Completion of Work :</b></td> <td>$d_o_c</td></tr>";
	echo "<tr><td><b>Depth of Boring : </b> </td><td>$depth M </td></tr>";
	echo "<tr><td><b><u>Materials Information</u> </b></td></tr>";
	echo "<tr><td><b>Vide Cash-Memo No : </b></td><td> $memo_no </td><td><b>dtd :</td><td>$d_o_memo</b></td><td><b>M/S :</b></td><td>$m_s_m</td></tr>";
	echo "<tr><td><b><u>Pump-Set Information</u> </b></td></tr>";
	echo "<tr><td><b>Vide Bill No : </b></td><td>$v_bill_no</td><td> <b>dtd :</b></td><td>$d_o_b</td><td><b>M/S :</b></td><td>$m_s_p</td></tr>";
	echo "<tr><td><input id='edit_bill' type='button' value='' onclick=\"Javascript:edit('$applicant_id')\"></td>
	          <td><input id='proceed' type='button' name='proceed' value='' onclick=\"Javascript:bill('$applicant_id')\"></td></tr>";
	}
	
}
echo "</table>";
?>
</body>
</html>
