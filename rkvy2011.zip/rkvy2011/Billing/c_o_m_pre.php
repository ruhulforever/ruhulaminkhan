<?php 
require_once '../Include/auth.php';
require_once '../Include/connect.php';
if(isset($_GET['applicant_id'])&&is_numeric($_GET['applicant_id']))
{
    $applicant_id=$_GET['applicant_id'];

$q="INSERT INTO material_cost (item_name, quantity, rate, amount, applicant_id) VALUES
('PVC Ribbed Screen Strainer of 90mm Dia ', 10, 215.00, 2150.00, '$applicant_id'),
('Hand Tube Well head, No.6', 1, 680.00, 680.00, '$applicant_id'),
('Combined Special Tee, (80X40X80)mm', 1, 150.00, 150.00, '$applicant_id'),
('End plug 90mm Dia', 1, 40.00, 40.00, '$applicant_id'),
('PVC Suction Pipe, 80mm Dia', 1, 103.00, 103.00, '$applicant_id'),
('PVC Male Thread Adaptor', 1, 30.00, 30.00, '$applicant_id'),
('GI Nipple (150X40)mm', 1, 30.00, 30.00, '$applicant_id'),
('PVC Socket', 3, 25.00, 75.00, '$applicant_id'),
('Light duty G.I Pipe of 80mm Dia, BIS-1239', 3, 255.00, 765.00, '$applicant_id'),
('Solvent cement', 1, 25.00, 25.00, '$applicant_id')";
$result=mysql_query($q,$link);
if($result)
    {
        //header("location: c_o_m.php?applicant_id=$applicant_id");
        echo "<script language='javascript'> window.location.href='c_o_m.php?applicant_id=$applicant_id'</script>";
		exit();
    }
}
else
echo "<h1><center>Error Accessed!</center></h1>";

?>