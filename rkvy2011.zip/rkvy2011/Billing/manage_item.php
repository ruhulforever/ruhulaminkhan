<html>
<head>
<title>Manage Item</title>
<link href="../Include/button.css" rel="StyleSheet" type="text/css">
<script language="javascript">
function delete_item(item_id)
{
    op=confirm("Are you sure to delete?");
    if(op)document.location.href="delete_item.php?id="+item_id;
      
}
function close_window()
{
	document.location.href="../Home/home.php";
}
function pump(form)
{
    var val=form.category.value;
    self.location="manage_item.php?category="+val;
}
</script>
</head>
<body background="../Include/Img/background.gif" style="background-size:cover;" bgcolor="#0099ff">
<?php 
require_once '../Include/auth.php';
require_once '../Include/connect.php';
require_once '../Include/header.php';
$q="SELECT * from item_table";
    $r=mysql_query($q,$link);
	$recs=mysql_num_rows($r); //total records 
if(isset($_GET['category'])&&is_numeric($_GET['category']))
{
	$cat_id=$_GET['category'];
}
$display=6;
if(isset($_GET['p'])&&is_numeric($_GET['p']))
{
	$pages=$_GET['p'];
}
else 
{
	$q="SELECT * from item_table";
    $r=mysql_query($q,$link);
	$records=mysql_num_rows($r);
	if($records>$display)
	{
		$pages=ceil($records/$display);
	}
	else 
	{
		$pages=1;	
	}
}
if(isset($_GET['s'])&&is_numeric($_GET['s']))
{
	$start=$_GET['s'];
}
else 
{
	$start=0;
}
?>

<b><center>ENTER ITEM DETAILS</center></b><br>
<form name="manage" method="post" action="manage_item.php">
  <table  border="0" align="center">
   <tr>
      <td><b>Item Category</b></td>
      <td><select name="category" onchange="pump(this.form)">
      				  <option value="">Select Item Category</option>
      				  <?php 
      				  if($cat_id==1)
      				  echo "<option selected value='1'>Materials</option>";
      				  if($cat_id==2)
      				  echo "<option selected value='2'>Installation Work</option>";
      				  if($cat_id==3)
      				  echo "<option selected value='3'>Pump-Set</option>";
      				  ?>
                      <option value="1">Materials</option>
                      <option value="2">Installation Work</option>
                      <option value="3">Pump-Set</option>
                      </select>
      </td>
      <?php 
       if($cat_id==3)
       echo "<td><b>H.P</b></td>
             <td><input name='hp' size='5' type='text'><img src='../Include/Img/optional.gif'></td>";
      ?>
    </tr>
    <tr>
      <td><b>Item Name</b></td>
      <td><input name="item_name" type="text" /></td>
    </tr>
    <tr>
      <td><b>Brand</b></td>
      <td><input name="brand" type="text"  /><img src='../Include/Img/optional.gif'></td>
    </tr>
    <tr>
      <td><b>Model</b></td>
      <td><input name="model" type="text"/><img src='../Include/Img/optional.gif'></td>
    </tr>
    <tr>
      <td><b>Price</b></td>
      <td><input name="price" type="text"/></td>
    </tr>
    <tr>
      <td></td><td><input id="add_item" type="submit" name="Submit" value="" ></td><td>
      <input type="button" id="close" name="back" value="" onclick="Javascript:close_window()"></td>
    </tr>
  </table>
</form>
<?php

/**
 * @author 
 * @copyright 2011
 */
 require_once('../Include/connect.php');
 $flag=0;
if(isset($_POST['item_name'])&&is_numeric($_POST['price'])&&isset($_POST['category'])&&is_numeric($_POST['category']))
{
	if(!isset($_POST['hp'])) 
        $hp="";
        else
        $hp=$_POST['hp'];
	if(!isset($_POST['brand'])) 
        $brand="";
        else
        $brand=$_POST['brand'];
    if(!isset($_POST['model'])) 
        $model="";
        else
        $model=$_POST['model'];
 $item_name=$_POST['item_name'];
 $cat_id=$_POST['category'];
 $price=$_POST['price'];
 $q="INSERT INTO item_table(item_name,cat_id,price,hp,brand,model) VALUES('$item_name',$cat_id,$price,'$hp','$brand','$model')";
$result=mysql_query($q,$link);
if($result) {
    $flag=1;
    @mysql_free_result($result);
    }
    else{
			die("Query failed");
        	}
}
//if($flag==1)
//echo "<center>Item added!</center>";
//showing current items
$q="SELECT * from item_table ORDER BY cat_id limit $start,$display";
$result=mysql_query($q,$link);
$num=mysql_num_rows($result);
if($num>0)
{
    echo "<p><center>There are currently $recs item. </center><p>\n";
 echo '<table  align="center" border="4" bgcolor="silver" width="75%">
<tr>
<td align="center"><b>Delete</b></td>
<td align="center"><b>Category</b></td>
<td align="center"><b>Item Name</b></td>
<td align="center"><b>H.P</b></td>
<td align="center"><b>Brand</b></td>
<td align="center"><b>Model</b></td>
<td align="center"><b>Price</b></td>
</tr>';
while ($row=mysql_fetch_array($result))
{
	if($row['cat_id']==1){
		$msg="Material";}
	elseif($row['cat_id']==2){
		$msg="Installation Work";}
	elseif($row['cat_id']==3){
		$msg="Pump-set";}
echo '<tr>
<td align="center"><a id="delete" href="Javascript:delete_item('.$row['item_no'].')">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></td>
<td align="left">'.$msg.'</td>
<td align="left">'.$row['item_name'].'</td>
<td align="left">&nbsp;'.$row['hp'].'</td>
<td align="left">&nbsp;'.$row['brand'].'</td>
<td align="left">&nbsp;'.$row['model'].'</td>
<td align="right">'.$row['price'].'</td></tr>';
}
echo '</table>';
mysql_free_result($result);
}
else
echo '<p><center>There are currently no items.</center></p>';
if($pages>1)
{
	echo "<table align='center'>";
	$current_page=($start/$display)+1;
	if($current_page!=1)
	{
		$prev=$start-$display;
		echo "<tr><td><b><a href='manage_item.php?s=$prev&p=$pages'>Previous</a></b></td>";
	}
	for($i=1;$i<=$pages;$i++)
	{
		if($i!=$current_page)
		{    
			$d=$display*($i-1);
			echo "<td><b><a href='manage_item.php?s=$d&p=$pages'>$i</a></b></td>";
		}
		else 
		{
			echo "<td><b>$i</b></td>";
		}
	}
	if($current_page!=$pages)
	{
		$n=$start+$display;
		echo "<td><b><a href='manage_item.php?s=$n&p=$pages'>Next</b></a></td></tr>";
	}
	echo "</table>";
}
?>
</body>
</html>
