<?php

/**
 * @author 
 * @copyright 2011
 */
require_once '../Include/auth.php';
require_once('../Include/connect.php');
if(isset($_GET['s'])&&isset($_GET['p']))
{
	$s=$_GET['s'];
	$p=$_GET['p'];
}
if(isset($_GET['applicant_id'])&&is_numeric($_GET['applicant_id']))
{
    //delete in cascading manner
    $applicant_id=$_GET['applicant_id'];
    $q="delete from bill_info where applicant_id=$applicant_id";
    $q1="delete from material_cost where applicant_id=$applicant_id";
    $q2="delete from install_cost where applicant_id=$applicant_id";
    $q3="delete from pump_cost where applicant_id=$applicant_id";
    $q4="delete from sum_cost where applicant_id=$applicant_id";
    $q5="delete from scoring where applicant_id=$applicant_id";
    $q6="update applicant set bill_status='0' where applicant_id=$applicant_id";
    $r=mysql_query($q,$link);
    $r1=mysql_query($q1,$link);
    $r2=mysql_query($q2,$link);
    $r3=mysql_query($q3,$link);
    $r4=mysql_query($q4,$link);
    $r5=mysql_query($q5,$link);
    $r6=mysql_query($q6,$link);
    if($r||$r1||$r2||$r3||$r4||$r5||$r6)
    {
     // header("location: ../Find/find_app.php?s=$s&p=$p");
      echo "<script language='javascript'> window.location.href='../Find/find_app.php?s=$s&p=$p'</script>";
    }
}


?>