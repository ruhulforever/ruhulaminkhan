<?php

/**
 * @author 
 * @copyright 2011
 */
require_once '../Include/auth.php';
require_once('../Include/connect.php');
if(isset($_GET['applicant_id'])&&is_numeric($_GET['applicant_id']))
{
    $applicant_id=$_GET['applicant_id'];
    $sum=0;
    $q="select amount from install_cost where applicant_id=$applicant_id"; ////////////////////////////
    $result=mysql_query($q,$link);
    $num=mysql_num_rows($result);
    for($i=0;$i<$num;$i++)
    {
        $row=mysql_fetch_array($result);
        $sum=$sum+$row['amount'];
    }
    $q="update sum_cost set install_cost=$sum where applicant_id=$applicant_id"; ///////////////////////////////////
    $result=mysql_query($q,$link);
    if($result)
    {
        //header("location: bill.php?applicant_id=$applicant_id");
        echo "<script language='javascript'> window.location.href='bill.php?applicant_id=$applicant_id'</script>";
		exit();
    }
}
else
echo "<h1><center>Error Accessed!</center></h1>";

?>