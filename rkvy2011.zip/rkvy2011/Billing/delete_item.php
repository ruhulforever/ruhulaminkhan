<?php

/**
 * @author 
 * @copyright 2011
 */
require_once '../Include/auth.php';
require_once('../Include/connect.php');

if(   (isset($_GET['id'])) && (is_numeric($_GET['id']))    )
{
$item_no=$_GET['id'];
}
/*else if( (isset($_GET['id'])) && (is_numeric($_GET['id'])) )
{
$id=$_POST['id'];
}*/
else
{
echo '<p> Error accessed !</p>';
exit();
}
	$q="DELETE FROM item_table WHERE item_no=$item_no LIMIT 1";

	$r=mysql_query($q,$link);
    if($r) {
		//header("location: manage_item.php");
		echo "<script language='javascript'> window.location.href='manage_item.php'</script>";
		exit();
	}else {
		die("Query failed");
	}
	  


mysql_close($link);


?>