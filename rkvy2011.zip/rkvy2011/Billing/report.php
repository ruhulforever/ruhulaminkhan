<html>
<head>
<title>Produced by RKVY Auto Billling</title>
<link href="../Include/button.css" rel="StyleSheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../Include/print.css" media="print"/>
</head>
<body bgcolor="#0099ff">
<?php

/**
 * @author Ruhul Amin Khan. (MCA 6th Semester)
 * @copyright 2011
 */
require_once '../Include/auth.php';
require_once('../Include/connect.php');
if(isset($_GET['applicant_id'])&&is_numeric($_GET['applicant_id']))
{
    $applicant_id=$_GET['applicant_id'];
    $q="select * from applicant where applicant_id=$applicant_id";
    $q1="select * from material_cost where applicant_id=$applicant_id";
    $q2="select * from install_cost where applicant_id=$applicant_id";
    $q3="select * from pump_cost where applicant_id=$applicant_id";
    $q4="select * from sum_cost where applicant_id=$applicant_id";
    $q5="select * from bill_info where applicant_id=$applicant_id";
    $qr=mysql_query($q,$link);
    $q1r=mysql_query($q1,$link);
    $q2r=mysql_query($q2,$link);
    $q3r=mysql_query($q3,$link);
    $q4r=mysql_query($q4,$link);
    $q5r=mysql_query($q5,$link);
    $row=mysql_fetch_array($qr);
    $sum_cost=mysql_fetch_array($q4r);
    $bill_info=mysql_fetch_array($q5r);
    //applicant data retrieved to display in tha final bill
    $group_id=$row['group_id'];
    $applicant_name=$row['applicant_name'];
	$group_name=$row['group_name'];
	$vill=$row['vill'];
	$po=$row['po'];
	$block=$row['block'];
	echo "<center><u><b>First and Final Bill For Installation of STW under RKVY</b></u></center>";
	echo "<br><br><b>Name of work :</b> Installation of STW under <b>RKVY (2010-11)</b><br>";
    echo "<b>Name of Site :</b> At the field of <b>Sri. $applicant_name</b><br>";
    echo "<b>Vill :</b> $vill <b>P.O :</b> $po <b> Block : </b> $block<br>";
    if($group_id==2) //shg
    echo "<b>Name of SHG :</b>$group_name<br>";
    if($group_id==3) //ahg
    echo "<b>Name of ASG :</b>$group_name<br>";
    if($bill_info['w_o_n']=="NA")
    	echo "<b>Work order No :</b> EE/Agri/Tez/T-98/10-11/________________ <b>dtd.</b> _____________ <br>";
    else 
    	echo "<b>Work order No :</b> EE/Agri/Tez/T-98/10-11/$bill_info[w_o_n] <b>dtd.</b> $bill_info[w_o_date]<br>";
    if($bill_info['d_o_c']=="0000-00-00")
    	echo "<b>Date of completion of works : ______________ </b> ";
    else 
    	echo "<b>Date of completion of works : </b> $bill_info[d_o_c] ";
    if($bill_info['depth']==0)
    	echo "<b>Depth of Boring : _______ M</b><br>";
    else 
    	echo "<b>Depth of Boring :</b> $bill_info[depth] M<br>";
    if($bill_info['mb_no']=="NA")
    	echo "<b>M.B No : ________ at Page No. ________ to ________</b><br><br>";
    else 
    	echo "<b>M.B No :</b> $bill_info[mb_no] <b>at Page No</b>. $bill_info[page_s] <b>to</b> $bill_info[page_e]<br><br>";
    //material_cost
    $num=mysql_num_rows($q1r); 
    if($num>0)
    {
    echo "<table align='center' border='1' bgcolor='silver' width='100%'>
    <tr>
    <td align='center'>&nbsp;</td>";
    echo "<td align='center'><small><b>Item of STW Boring Materials</b></small></td>";
    echo "<td align='center'><b><small>Quantity</small></b></td>
    <td align='center'><b><small>Rate</small></b></td>
    <td align='center'><b><small>Amount</small></b></td>
    </tr>";
    echo "<tr><td><small><b>Item No.</b></small></td>";
    if($bill_info['memo_no']=="NA")
    {
    	echo "<td><small><b>[A].  COST OF MATERIALS (Including sale tax)<br>";
    	echo "Vide Cash-Memo No:</b> ________________________ <b>dtd.</b> _____________ <b>M/S.</b>_____________________</small></td>";
    }
    else 
    {
    	echo "<td><small><b>[A].  COST OF MATERIALS (Including sale tax)<br>";
    	echo "Vide Cash-Memo No :</b> $bill_info[memo_no] <b>dtd.</b> $bill_info[d_o_memo] <b>M/S .</b> $bill_info[m_s_m]</small></td>";
    }
    echo      "<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>";
    $sl_no=0;
        while ($row=mysql_fetch_array($q1r))
        {
        $sl_no+=1;
        echo '<tr>
        <td align="center"><small>'.$sl_no.'</small></td>
        <td align="left"><small>'.$row['item_name'].'</small></td>
        <td align="center"><small>'.$row['quantity'].'</small></td>
        <td align="right"><small>'.$row['rate'].'</small></td>
        <td align="right"><small>'.$row['amount'].'</small></td></tr>';
        }
    echo '<tr><td>&nbsp;</td><td align="right"><small><b>TOTAL [A]  =&nbsp;&nbsp;</b></small></td><td>&nbsp;</td><td align="right"><small><b>Rs.</b></small></td><td align="right"><small><b>'.$sum_cost['mat_cost'].'</b></small></td></tr>';
    //echo '</table>';
///total amount can be shown here for materia_cost    
    }
///////new table
 $num=mysql_num_rows($q2r); 
    if($num>0)
    {
   // echo '<table id="border" align="center" border="1" width="100%">
    echo '<br><tr>
    <td align="center"><b><small>Item No.</small></b></td>
    <td><b><small>[B].  COST OF INSTALLATION WORK</small></b></td>
    <td align="center"><b>&nbsp;</td>
    <td align="center"><b>&nbsp;</td>
    <td align="center"><b>&nbsp;</td>
    </tr>';
    $sl_no=0;
        while ($row=mysql_fetch_array($q2r))
        {
        $sl_no+=1;
        echo '<tr>
        <td align="center"><small>'.$sl_no.'</small></td>
        <td align="left"><small>'.$row['item_name'].'</small></td>
        <td align="center"><small>'.$row['quantity'].'</small></td>
        <td align="right"><small>'.$row['rate'].'</small></td>
        <td align="right"><small>'.$row['amount'].'</small></td></tr>';
        }
    echo '<tr><td>&nbsp;</td><td align="right"><small><b>TOTAL [B]  =&nbsp;&nbsp;</b></small></td><td>&nbsp;</td><td align="right"><small><b>Rs.</b></small></td><td align="right"><small><b>'.$sum_cost['install_cost'].'</b></small></td></tr>';
    //echo '</table>';
    }
$civil_work=$sum_cost['mat_cost']+$sum_cost['install_cost'];
$civil=($civil_work-3);
echo '<tr><td>&nbsp;</td><td align="right"><b>(i)</b><small><b> &nbsp;&nbsp; Total Cost of the STW (Civil works)  [A+B]  =&nbsp;&nbsp;</b></small></td><td>&nbsp;</td><td align="right"><small><b>Rs.</b></small></td><td align="right"><small><b>'.$civil_work.'.00</b></small></td></tr>';
echo '<tr><td>&nbsp;</td><td align="right"><b>(i)</b><small><b> &nbsp;&nbsp; Total Cost of the STW (Civil works)  [A+B] Say  =&nbsp;&nbsp;</b></small></td><td>&nbsp;</td><td align="right"><small><b>Rs.</b></small></td><td align="right"><small><b>'.$civil.'.00</b></small></td></tr>';
/////new table
 $num=mysql_num_rows($q3r); 
    if($num>0)
    {
    //echo '<table id="border" align="center"  border="1" width="100%">
    echo '<tr>
    <td align="center"><b><small>Item.No.</small></b></td>';
    if($bill_info['v_bill_no']=="NA")
    {
    	echo "<td><b><small>[C].  COST OF PUMP-SET (Including testing, commissioning etc. and cost of
          delivering up to site) <br>";
    	echo "Vide Bill No :</b> _____________________<b>dtd .</b>____________ <b> M/S. </b> _____________________</small></td>";
    }
    else 
    {
    	echo "<td><b><small>[C].  COST OF PUMP-SET (Including testing, commissioning etc. and cost of
          delivering up to site) <br>";
    	echo "Vide Bill No :</b> $bill_info[v_bill_no]<b>dtd .</b>$bill_info[d_o_b] <b> M/S. </b> $bill_info[m_s_p]</small></td>";
    }
    echo '<td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>';
    $sl_no=0;
        while ($row=mysql_fetch_array($q3r))
        {
        $sl_no+=1;
        echo '<tr>
        <td align="center"><small>'.$sl_no.'</small></td>
        <td align="left"><small>'.$row['item_name'].'</small></td>
        <td align="center"><small>'.$row['quantity'].'</small></td>
        <td align="right"><small>'.$row['rate'].'</small></td>
        <td align="right"><small>'.$row['amount'].'</small></td></tr>';
        }
    echo '<tr><td>&nbsp;</td><td align="right"><small><b>TOTAL [C]  =&nbsp;&nbsp;</b></small></td><td>&nbsp;</td><td align="right"><small><b>Rs.</b></small></td><td align="right"><small><b>'.$sum_cost['pump_cost'].'</b></small></td></tr>';
    echo '</table>';
    
    }
///tabulation finish
echo "<br>";
$total_c=round($civil+$sum_cost['pump_cost']);
if($total_c>34000)
{
	$gs=20400;
}
else 
{
	$gs=round(($total_c*60)/100);
}
$fs=round($total_c-$gs);
$deposited=round($fs-$civil);

//echo "<b>Total[A]= Rs. $sum_cost[mat_cost]</b><br>";
//echo "<b>Total[B]= Rs. $sum_cost[install_cost]</b><br>";
//echo "<b>Total[C]= Rs. $sum_cost[pump_cost]</b><br>";
echo "<b>(ii) Total cost of STW [A+B+C] = Rs. $total_c</b><br>";
echo "<b>(iii) Govt. Subsidy (<small>60% of Rs. 34,000/- i.e Rs. 20,400/- or 60% of the cost whichever is less</small>) =  Rs. $gs</b><br>";
echo "<b>(iv) Farmer's Share  [ (ii)-(iii) ]           = Rs. $fs</b><br>";
//echo "<b>Total cost of STW (Civil works) [A+B] = Rs. $civil_work</b><br>";
echo "<b>(v) Farmer's Share to be deposited for Pump set in the form of Bank Draft [ (iv)-(i) ] = Rs. $deposited</b><br><br>";
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>(Rupees</b> .........................................................................................................................<b>)only</b>";
echo '<br><br><br><br><table align="center" border="0" width="100%">';
echo '<tr><td align="center"><b><u>Countersigned By</u></b></td><td align="center"><b><u>Checked By</u></b></td><td align="center"><b><u>Prepared By</u></b></td></tr>';
echo '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
echo '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
echo '<tr><td align="center">Executive Engineer (Agri)</td><td align="center">Asstt. Agril. Engineer (Agri)</td><td align="center">Junior Engineer (Agri)</td></tr>';
echo '<tr><td align="center">Tezpur Division</td><td align="center">Tezpur Division</td><td align="center">Tezpur Division</td></tr>';
echo '</table>';
echo "<div id='noprint'>";
echo "<center><input id='close' type='submit' value='' onclick='window.close();'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input id='print' type='submit' value='' onclick='window.print();'></center>";
echo "</div>";
}
?>
</body>
</html>