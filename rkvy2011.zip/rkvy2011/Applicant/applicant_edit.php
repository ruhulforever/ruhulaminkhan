<html>
<head>
<title>Applicant's Info for R.K.V.Y.2011</title>
<link href="../Include/button.css" rel="StyleSheet" type="text/css">
<script src="../Include/Calender/prototype.js" type="text/javascript"></script>
<script src="../Include/Calender/rico.js" type="text/javascript"></script>
<script src="../Include/validate.js" type="text/javascript"></script>
<script src="../Include/mycal.js" type="text/javascript"></script>
<script type="text/javascript">
function group(form)
{
    var val=form.group_id.value;
    self.location='applicant.php?group_id='+val;
}
function create_bill(flag)
{   
	<?php if(is_numeric($_GET['applicant_id']))
        $applicant_id=$_GET['applicant_id'];
    ?>
    if(flag==1)
        op=confirm("Are you sure to create bill for this applicant ?");
    if(flag==2)
    	op=confirm("Are you sure to Edit bill for this applicant ?");
    if(op)window.open("../Billing/bill.php?applicant_id=<?php echo $applicant_id;?>");
}
function view_bill()
{
	<?php if(is_numeric($_GET['applicant_id']))
	         $applicant_id=$_GET['applicant_id'];
	?>
	window.open("../Billing/report.php?applicant_id=<?php echo $applicant_id;?>");
}
function applicant_delete(applicant_id)
{
    op=confirm("Are you sure to delete this applicant ?");
    if(op)document.location.href="applicant_delete.php?applicant_id="+applicant_id;
}
function redirect()
{
	document.location.href="applicant.php";
}
</script>
</head>
<body background="../Include/Img/background.gif" style="background-size:cover;" bgcolor="#0099ff" >
<?php
require_once '../Include/auth.php'; 
require_once '../Include/connect.php';
require_once '../Include/header.php';
$flag=0;
if(isset($_GET['group_id'])&&is_numeric($_GET['group_id']))
{
	$get_id=$_GET['group_id'];
}
if(is_numeric($_GET['applicant_id']))
{
	$applicant_id=$_GET['applicant_id'];
	$q="select * from applicant where applicant_id=$applicant_id";
	$q1="select * from scoring where applicant_id=$applicant_id";
	$r=mysql_query($q,$link);
	$r1=mysql_query($q1,$link);
	$row=mysql_fetch_array($r); //retrieving applicant info from table applicant
	$row1=mysql_fetch_array($r1); //retrieving applicant info from table scoring
	$applicant_name=$row['applicant_name'];
	$group_name=$row['group_name'];
	$n_o_group=$row['n_o_group'];
	$d_o_e=$row['d_o_e'];
	$n_o_m=$row['n_o_m'];
	$n_o_m_o=$row['n_o_m_o'];
	$gp=$row['gp'];
	$ap=$row['ap'];
	$zp=$row['zp'];
	$block=$row['block'];
	$sub_division=$row['sub_division'];
	$vill=$row['vill'];
	$po=$row['po'];
	$ph_no=$row['ph_no'];
	$t_land=$row['t_land'];
	$c_land=$row['c_land'];
	$bill_status=$row['bill_status'];
	//retrieved from table scoring
	$w_c_f_s=$row1['w_c_f_s'];
	$is_defaulter=$row1['is_defaulter'];
	$i_f=$row1['i_f'];
	$w_section=$row1['w_section'];
	$n_o_w_f=$row1['n_o_w_f'];
	$f_used=$row1['f_used'];
	$c_intensity=$row1['c_intensity'];
	$bank_amount=$row1['bank_amount'];
	$tm=$row1['tm'];
}
$series=range(0,100);
echo "<form name='applicant' method='post' onsubmit=\"validate(this)\" action='applicant_edit.php?applicant_id=$applicant_id&group_id=$get_id'>";
        echo "<table align='left' width='100%' height='200'>";
        echo "<th  align='left'><b><u>APPLICANT INFORMATION</u></b></th>";
        echo "<tr><td><b>Applicant Category</td><td><select name='group_id' onchange=\"group(this.form)\">
                      <option value=''>Select Category</option>
                      <option value='1'>Individual</option>
                      <option value='2'>S.H.G</option>
                      <option value='3'>A.S.G</option>";
        			  if($get_id==1){
        			  	echo "<option selected value='1'>Individual</option>";}
        			  if($get_id==2){
        			  	echo "<option selected value='2'>S.H.G</option>";}
        			  if($get_id==3){
        			  	echo "<option selected value='3'>A.S.G</option>";}
        			  
                      echo "</select></td>";
        if($get_id==1){
        	echo "<td><b>Farmer's Name</td><td><input type='text' name='applicant_name' value='$applicant_name'></td></tr>";
        }
        elseif ($get_id==2){
        	echo "<td><b>Representative's Name</td><td><input type='text' name='applicant_name' value='$applicant_name'></td>";
        	echo "<td><b>S.H.G Name</td><td><input type='text' name='group_name' value='$group_name'></td>";
        }
        elseif ($get_id==3){
        	echo "<td><b>Representative's Name</td><td><input type='text' name='applicant_name' value='$applicant_name'></td>";
        	echo "<td><b>A.S.G Name</td><td><input type='text' name='group_name' value='$group_name'></td>";
        }
        else {
        	echo "</tr>";
        }
        if($get_id==2||$get_id==3)
        {
        	echo "<td><b>No. of Group Members</td><td><select name='n_o_group'>
        											  <option value=''>Select</option>";
        	                            if($n_o_group)
        	                             echo "<option selected value='$n_o_group'>$n_o_group</option>\n";
        								     foreach($series as $value)
      									{
        								echo "<option value='$value'>$value</option>\n";
      									}
      
     								    echo "</select></td></tr>";
        }
        $curdate=date("Y-m-d");
        if($d_o_e)
        {
        	echo "<tr><td><b>Date of Entry</td><td><input type='text' id='CalendarValue' name='d_o_e' value='$d_o_e'>
        		         <a href=''><img id='CalendarButton' src='../Include/Img/cal.gif' onclick=\"CalendarClick(event)\"></a>
                  </td>";
        }
        else 
        {
        	echo "<tr><td><b>Date of Entry</td><td><input type='text' id='CalendarValue' name='d_o_e' value='$curdate'>
        		         <a href=''><img id='CalendarButton' src='../Include/Img/cal.gif' onclick=\"CalendarClick(event)\"></a>
                  </td>";
        }
        		  echo "<td><b>Name of Macinery</td><td><input type='text' name='n_o_m' value='$n_o_m'></td>
        		  <td><b>Machinery Obtained</td><td><select name='n_o_m_o'>
        											  <option value=''>Select</option>";
        		                        if($n_o_m_o)
        	                             echo "<option selected value='$n_o_m_o'>$n_o_m_o</option>\n";
        								     foreach($series as $value)
      									{
        								echo "<option value='$value'>$value</option>\n";
      									}
      
     								    echo "</select></td>
              </tr>";
        echo "<tr><td><b>G.P</td><td><input type='text' name='gp' value='$gp'></td>
                  <td><b>A.P</td><td><input type='text' name='ap' value='$ap'></td>
                  <td><b>Z.P</td><td><input type='text' name='zp' value='$zp'></td>
                  <td><b>Block</td><td><input type='text' name='block' value='$block'></td>
              </tr>";
        echo "<tr>
                  <td><b>Sub-Division</td><td><input type='text' name='sub_division' value='$sub_division'>
                                                               <img src='../Include/Img/optional.gif'></td>
                  <td><b>Village</td><td><input type='text' name='vill' value='$vill'></td>
                  <td><b>P.O</td><td><input type='text' name='po' value='$po'></td>  
                  <td><b>Phone/Record No.</td><td><input type='text' name='ph_no' value='$ph_no'></td>    
        </tr>";
        echo "<tr><td><b>Total Land</td><td><input type='text' name='t_land' value='$t_land'></td>
                  <td><b>Cultivable Land</td><td><input type='text' name='c_land' value='$c_land'></td>
        </tr>";
       // echo "</table><br>";
        //echo "<table height='20' width='100%'>";
        //echo "<th bgcolor='#808040' align='left'></th><br>";
        //echo "</table><br>";
        //echo "<table bgcolor='#808030' align='left' width='50%' height='300'>";
        echo "<th  align='left'><b><u>INFORMATION FOR AUTO SCORE GENERATION</u></b></th>";
        echo "<tr><td><b>Amount in Bank Account</td>
                  <td><input type='text' name='bank_amount' value='$bank_amount'>
                      <img src='../Include/Img/optional.gif'></td>
              </tr>";
        echo "<tr><td><b>Willingness to Contribute Farmer's Share</td><td><select name='w_c_f_s'>
                      <option value=''>Select</option>";
                      if($w_c_f_s==1)
                       echo "<option selected value='1'>Yes</option>";
                      if($w_c_f_s==0)
                       echo "<option selected value='0'>No</option>";
                       echo "<option value='0'>No</option>";
                       echo "<option  value='1'>Yes</option>";
        echo "</select></td></tr>";
        echo "<tr><td><b>If any member is defaulter any bank loan</td><td><select name='is_defaulter'>
                      <option value=''>Select</option>";
        			  if($is_defaulter==0)
                       echo "<option selected value='0'>Yes</option>";
                      if($is_defaulter==1)
                       echo "<option selected value='1'>No</option>";
                       echo "<option value='0'>Yes</option>";
                       echo "<option value='1'>No</option>";
        echo "</select></td></tr>";
        echo "<tr><td><b>Irrigation Facilities Within the Group</td><td><select name='i_f'>
                      <option value=''>Select</option>";
        			  if($i_f==0)
                       echo "<option selected value='0'>LLP Electric</option>";
                      if($i_f==1)
                       echo "<option selected value='1'>LLP Diesel</option>";
                      if($i_f==2)
                       echo "<option selected value='2'>STW</option>";
                      if($i_f==3)
                       echo "<option selected value='3'>None</option>"; 
                       echo "<option  value='0'>LLP Electric</option>";
                       echo "<option  value='1'>LLP Diesel</option>";
                       echo "<option  value='2'>STW</option>";
                       echo "<option  value='3'>None</option>";
                       echo "</select></td> </tr>";
        echo "<tr><td><b>Presence of Weaker Section(ST/SC) in the Group</td><td><select name='w_section'>
        											  <option value=''>Select</option>";
                                        if($w_section)
        	                             echo "<option selected value='$w_section'>$w_section</option>\n";
        								     foreach($series as $value)
      									{
        								echo "<option value='$value'>$value</option>\n";
      									}
      
     								    echo "</select></td>
              </tr>";
       echo "<tr><td><b>No. of Women Farmers in the Group</td><td><select name='n_o_w_f'>
        											  <option value=''>Select</option>";
       									if($n_o_w_f)
        	                             echo "<option selected value='$n_o_w_f'>$n_o_w_f</option>\n";
        								     foreach($series as $value)
      									{
        								echo "<option value='$value'>$value</option>\n";
      									}
      
     								    echo "</select></td>
              </tr>";
     	echo "<tr><td><b>Use of Fertilizer in Existing Operation</td><td><select name='f_used'>
                      <option value=''>Select</option>";
                      if($f_used==0)
                       echo "<option selected value='0'>Full</option>";
                      if($f_used==1)
                       echo "<option selected value='1'>Fifty</option>";
                      if($f_used==2)
                       echo "<option selected value='2'>Average</option>";
                       
                       echo "<option value='0'>Full</option>";
                       echo "<option value='1'>Fifty</option>";
                       echo "<option value='2'>Average</option>";
                       echo "</select></td></tr>";
     	echo "<tr><td><b>Present Cropping Intensity</td><td><select name='c_intensity'>
        											  <option value=''>Select</option>";
     	                                if($c_intensity)
        	                             echo "<option selected value='$c_intensity'>$c_intensity</option>\n";
        								     foreach($series as $value)
      									{
        								echo "<option value='$value'>$value</option>\n";
      									}
      
     								    echo "</select></td>
              </tr><tr></tr>";
        echo "<tr ><td><b><input id='update' type='submit' name='submit' value=''></b><td>
                                        <b><input id='close' type='button' name='close' value='' onclick='window.close();'></td>";
                                                                                
     	echo "<td></td></tr>";
     	echo "</form>";
// validating and updating applicant record against specific applicant_id received through query string
if(isset($_POST['submit'])&&isset($_POST['group_id'])&&isset($_POST['n_o_m'])&&isset($_POST['n_o_m_o'])&&isset($_POST['gp'])&&isset($_POST['ap'])&&
   isset($_POST['po'])&&isset($_POST['zp'])&&isset($_POST['block'])&&isset($_POST['vill'])&&isset($_POST['t_land'])&&isset($_POST['c_land'])&&
   isset($_POST['w_c_f_s'])&&isset($_POST['is_defaulter'])&&isset($_POST['i_f'])&&isset($_POST['w_section'])&&isset($_POST['n_o_w_f'])&&
   isset($_POST['f_used'])&&isset($_POST['c_intensity']))
{
	$group_id= $_POST[group_id];
    $applicant_name= $_POST[applicant_name];
	$group_name=$_POST[group_name];
	if($group_id==1)
	{
	 $n_o_group=0;	
	}
	else 
	{
	 $n_o_group= $_POST[n_o_group];
	}
	$d_o_e= $_POST[d_o_e];
	$vill=$_POST[vill];
	$po= $_POST[po];
	$gp= $_POST[gp];
	$ap= $_POST[ap];
	$zp= $_POST[zp];
	$block= $_POST[block];
	$sub_division=$_POST[sub_division];
	$t_land=$_POST[t_land];
	$c_land=$_POST[c_land];
	$n_o_m=$_POST[n_o_m];
	$n_o_m_o=$_POST[n_o_m_o];
    $ph_no=$_POST[ph_no];
    /// variables for mark generation
	if(is_numeric($_POST[bank_amount]))
	{
		$bank_amount=$_POST[bank_amount];
	}
	else 
	{
		$bank_amount=0;
	}
	$w_c_f_s=$_POST[w_c_f_s];
	$is_defaulter=$_POST[is_defaulter];
	$i_f=$_POST[i_f];
	$w_section=$_POST[w_section];
	$n_o_w_f=$_POST[n_o_w_f];
	$f_used=$_POST[f_used];
	$c_intensity=$_POST[c_intensity];
	/// calculating total marks gained by an applicant or a group based on conditions opted
	$tm=$w_c_f_s+$is_defaulter+$i_f+$w_section+$n_o_w_f+$f_used+$c_intensity;
	
	$q="update applicant set group_id='$group_id',applicant_name='$applicant_name',group_name='$group_name',n_o_group='$n_o_group',
							 d_o_e='$d_o_e',vill='$vill',po='$po',gp='$gp',ap='$ap',zp='$zp',block='$block',sub_division='$sub_division',
							 t_land='$t_land',c_land='$c_land',n_o_m='$n_o_m',n_o_m_o='$n_o_m_o',ph_no='$ph_no' 
						  where applicant_id=$applicant_id limit 1";
	
	$r=mysql_query($q,$link);
	if($r)
	{
		$q1="update scoring set w_c_f_s='$w_c_f_s',is_defaulter='$is_defaulter',i_f='$i_f',w_section='$w_section',n_o_w_f='$n_o_w_f',f_used='$f_used',
		                        bank_amount='$bank_amount',c_intensity='$c_intensity',tm='$tm'
		                    where applicant_id=$applicant_id limit 1";
		$r1=mysql_query($q1,$link);
		$flag=1;
	}
	// displaying updated information
	if($flag==1)
	{
	     echo "<br><th><b><u>VERIFY RECORDED INFORMATION</u></b></th>";
        if($group_id==1)
        echo "<tr><td><b>Farmer's Name </b></td><td>$applicant_name </td></tr>";
        if($group_id==2)
        {
        echo "<tr><td><b>Representative's Name  </b></td><td>$applicant_name</td></tr>";
        echo "<tr><td><b>S.H.G Name   </b></td><td>$group_name </td><td><b>No. of Group Members </b></td><td>$n_o_group</td></tr>";
        }
        if($group_id==3)
        {
        echo "<tr><td><b>Representative's Name  </b></td><td>$applicant_name </td></tr>";	
        echo "<tr><td><b>A.S.G Name </b></td><td> $group_name </td><td><b>No. of Group Members :</b></td><td>$n_o_m_o</td></tr>";
        }
        echo "<tr><td><b>Date of Entry </b></td> <td>$d_o_e</td><td> <b>Name of Machinery </b></td><td>$n_o_m</td></tr>";
        echo "<tr><td><b>Machinery Obtained </b></td><td>$n_o_m_o </td><td><b>GP </b></td><td> $gp</td></tr>";
        echo "<tr><td><b>A.P  </b></td><td>$ap </td><td><b>Z.P  </b></td><td>$zp</td></tr>";
        echo "<tr><td><b>Block  </b></td><td>$block </td><td><b>Sub Division  </b></td><td>$sub_division</td></tr>";
        echo "<tr><td><b>Village  </b></td><td> $vill </td><td><b>P.O  </b></td><td>$po</td></tr>";
        echo "<tr><td><b>Phone/Record No  </b> </td><td>$ph_no </td><td><b>Total Land  </b></td><td>$t_land</td></tr>";
        echo "<tr><td><b>Cultivable Land  </b></td><td> $c_land </td><td><b>Total Marks  </b></td><td> $tm</td></tr>";
        
         
    }
       
	mysql_close($link);
}

        //echo "&nbsp;&nbsp;&nbsp;<a href=\"Javascript:applicant_delete('$applicant_id')\">Delete Applicant</a>";
       /* if($bill_status==0)
         echo "&nbsp;&nbsp;&nbsp;<a href=\"Javascript:create_bill('1')\">Create Bill</a>";
        if($bill_status==1)
        {
         echo "&nbsp;&nbsp;&nbsp;<a href=\"Javascript:create_bill('2')\">Edit Bill</a>";
         echo "&nbsp;&nbsp;&nbsp;<a href=\"Javascript:view_bill()\">View Bill</a>";
        }*/
echo "</table>";
?>

</body>
</html>
