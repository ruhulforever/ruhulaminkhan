<?php
//header("location: Login/login.php");
echo "<script language='javascript'> window.location.href='Login/login.php'</script>";
?>