<html>
<head>
<title>Batch Printing Module for R.K.V.Y.2011</title>
<link rel="stylesheet" type="text/css" href="../Include/print.css" media="print"/>
<link href="../Include/button.css" rel="StyleSheet" type="text/css">
<script src="../Include/Calender/prototype.js" type="text/javascript"></script> 
<script src="../Include/Calender/rico.js" type="text/javascript"></script>
<script src="../Include/mycal.js" type="text/javascript"></script>
<script src="../Include/ajaxfunctions.js" type="text/javascript"></script>
<script type="text/javascript">
function redirect()
{
	document.location.href="../Home/home.php";
}
</script>
</head>
<body bgcolor="#0099ff">
<?php 
require_once '../Include/connect.php';
echo "<div id='noprint'>";
require_once '../Include/header.php';
echo "<b><center style='color: #003300;'><h2><u>SYNOPSIS OF RKVY STW/LLP</u></h2></center></b>";
echo "<form method='post'  action='synopsis.php'>";
echo "<table background='../Include/Img/table1.gif' align='center'>";
echo "<tr align='center'><td></td><td><b>Date From</b></td><td><input type='text' size='9' id='CalendarValue' name='s_date' value='$s_date'>
        		         <a href=''><img id='CalendarButton' src='../Include/Img/cal.gif' onclick=\"CalendarClick(event)\"></a>
                     </td><td><b>To</b></td>
                     <td><input type='text' size='9' id='CalendarValue1' name='e_date' value='$e_date'>
        		         <a href=''><img id='CalendarButton1' src='../Include/Img/cal.gif' onclick=\"calendar(event)\"></a>
                     </td>
                     <td><input id='find' type='submit' name='find_date' value=''></td><td>&nbsp;</td>";
echo "</form>";
echo "<form method='post' action='synopsis.php'>";
echo "<td align='right'><b>Record No </b>&nbsp; <input type='text' size='10' name='s_ph_no' value=''></td>";
echo "<td><b>To</b> &nbsp;<input type='text' size='10' name='e_ph_no' value=''></td>";
echo "<td><input id='find' type='submit' name='find_mobile' value=''></td></tr>";
echo "</table>";
echo "</form>";
echo "<br><br><center><input id='close' type='submit' value='' onclick='redirect();'></center>";
if(isset($_POST['find_date'])&&isset($_POST['s_date'])&&isset($_POST['e_date']))
{
	$s_date=$_POST['s_date'];
	$e_date=$_POST['e_date'];
	$q="select * from applicant where (d_o_e between '$s_date' and '$e_date') order by d_o_e";
	$r=mysql_query($q,$link);
}
if(isset($_POST['find_mobile'])&&isset($_POST['s_ph_no'])&&isset($_POST['e_ph_no']))
{
	$s_ph_no=$_POST['s_ph_no'];
	$e_ph_no=$_POST['e_ph_no'];
	$q="select * from applicant where (ph_no between '$s_ph_no' and '$e_ph_no') order by ph_no";
	$r=mysql_query($q,$link);
}
$num=mysql_num_rows($r);
if($num>0)
{
echo "<br><br><center><input id='print' type='submit' value='' onclick='window.print();'></center>";
echo "<br><center><b><font color='#0000ff'><MARQUEE WIDTH='40%' behavior='alternate' direction='right' scrollamount='10' >Total $num Applicant record is ready to print !</MARQUEE></font></b></center><br>";
echo "</div>";
$no=0;
echo "<center><u><b>APPLICANT INFORMATION FOR RKVY STW/LLP</b></u></center><br>";
while ($row=mysql_fetch_array($r))
{
	$no++;
	echo "<center><b><u> Sl No. $no </u></b></center>";
	$applicant_id=$row['applicant_id'];
	$q1="select * from scoring where applicant_id=$applicant_id";
	$r1=mysql_query($q1,$link);
	$row1=mysql_fetch_array($r1); //retrieving applicant info from table scoring
	$group_id=$row['group_id'];
	$applicant_name=$row['applicant_name'];
	$group_name=$row['group_name'];
	$n_o_group=$row['n_o_group'];
	$d_o_e=$row['d_o_e'];
	$n_o_m=$row['n_o_m'];
	$n_o_m_o=$row['n_o_m_o'];
	$gp=$row['gp'];
	$ap=$row['ap'];
	$zp=$row['zp'];
	$block=$row['block'];
	$sub_division=$row['sub_division'];
	$vill=$row['vill'];
	$po=$row['po'];
	$ph_no=$row['ph_no'];
	$t_land=$row['t_land'];
	$c_land=$row['c_land'];
	$bill_status=$row['bill_status'];
	//retrieved from table scoring
	$w_c_f_s=$row1['w_c_f_s'];
	$is_defaulter=$row1['is_defaulter'];
	$i_f=$row1['i_f'];
	$w_section=$row1['w_section'];
	$n_o_w_f=$row1['n_o_w_f'];
	$f_used=$row1['f_used'];
	$c_intensity=$row1['c_intensity'];
	$bank_amount=$row1['bank_amount'];
	$tm=$row1['tm'];
		echo "<br><table border='2' bgcolor='silver' width='90%' align='center'>";
		if($group_id==1)
		echo "<tr><td><b>Farmer's Name </b></td><td>$applicant_name </td><td>&nbsp;</td><td>&nbsp;</td></tr>";
        if($group_id==2)
        {
        echo "<tr><td><b>Representative's Name  </b></td><td>$applicant_name</td><td>&nbsp;</td><td>&nbsp;</td></tr>";
        echo "<tr><td><b>S.H.G Name   </b></td><td>$group_name </td><td><b>No. of Group Members </b></td><td>$n_o_group</td></tr>";
        }
        if($group_id==3)
        {
        echo "<tr><td><b>Representative's Name  </b></td><td>$applicant_name </td></tr>";	
        echo "<tr><td><b>A.S.G Name </b></td><td> $group_name </td><td><b>No. of Group Members :</b></td><td>$n_o_m_o</td></tr>";
        }
        echo "<tr><td><b>Date of Entry </b></td> <td>$d_o_e</td><td> <b>Name of Machinery </b></td><td>$n_o_m</td></tr>";
        echo "<tr><td><b>Machinery Obtained </b></td><td>$n_o_m_o </td><td><b>GP </b></td><td> $gp</td></tr>";
        echo "<tr><td><b>A.P  </b></td><td>$ap </td><td><b>Z.P  </b></td><td>$zp</td></tr>";
        echo "<tr><td><b>Block  </b></td><td>$block </td><td><b>Sub Division  </b></td><td>$sub_division</td></tr>";
        echo "<tr><td><b>Village  </b></td><td> $vill </td><td><b>P.O  </b></td><td>$po</td></tr>";
        echo "<tr><td><b>Phone/Record No  </b> </td><td>$ph_no </td><td><b>Total Land  </b></td><td>$t_land</td></tr>";
        echo "<tr><td><b>Cultivable Land  </b></td><td> $c_land </td><td><b>Total Marks  </b></td><td> $tm</td></tr>";
        
        if($bill_status==1)
                echo "<tr><td><b>Bill Prepared</b></td><td> Yes </td><td>&nbsp;</td><td>&nbsp;</td></tr>";
        else 
        		echo "<tr><td><b>Bill Prepared</b></td><td> No </td><td>&nbsp;</td><td>&nbsp;</td></tr>";
        echo "</table><br><br>";
	if($no%3==0)
	{
		echo "<center style='page-break-after: always;'>&nbsp;</center>";
		echo "<center><u><b>APPLICANT INFORMATION FOR RKVY STW/LLP</b></u></center><br>";
	}
}
		echo '<br><br><br><br><table align="center" border="0" width="100%">';
		echo '<tr><td align="center"><b><u>Countersigned By</u></b></td><td align="center"><b><u>Checked By</u></b></td><td align="center"><b><u>Prepared By</u></b></td></tr>';
		echo '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
		echo '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
		echo '<tr><td align="center">Executive Engineer (Agri)</td><td align="center">Asstt. Agril. Engineer (Agri)</td><td align="center">Junior Engineer (Agri)</td></tr>';
		echo '<tr><td align="center">Tezpur Division</td><td align="center">Tezpur Division</td><td align="center">Tezpur Division</td></tr>';
		echo '</table>';
}
?>
</body>
</html>