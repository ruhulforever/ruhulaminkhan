<?php
			session_start();
			unset($_SESSION['s_date']);
			unset($_SESSION['e_date']);
			unset($_SESSION['s_ph_no']);
			unset($_SESSION['e_ph_no']);
			unset($_SESSION['ph_no']);
			unset($_SESSION['s']);
			unset($_SESSION['p']);
			//header("location: ../Home/home.php");
			echo "<script language='javascript'> window.location.href='../Home/home.php'</script>";
		
?>