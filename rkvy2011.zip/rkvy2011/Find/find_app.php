<html>
<head>
<title>Find Module for R.K.V.Y.2011</title>
<link href="../Include/button.css" rel="StyleSheet" type="text/css">
<script src="../Include/Calender/prototype.js" type="text/javascript"></script> 
<script src="../Include/Calender/rico.js" type="text/javascript"></script>
<script src="../Include/mycal.js" type="text/javascript"></script>
<script src="../Include/ajaxfunctions.js" type="text/javascript"></script>

<script type="text/javascript">
function applicant_delete(applicant_id,s,p)
{
    op=confirm("Are you sure to delete this applicant ?");
    if(op)document.location.href='applicant_delete.php?applicant_id='+applicant_id+'&s='+s+'&p='+p;
}
function delete_bill(applicant_id,s,p)
{
    op=confirm("Are you sure to delete this Bill ?");
    if(op)document.location.href='../Billing/bill_delete.php?applicant_id='+applicant_id+'&s='+s+'&p='+p;
}
</script>
</head>
<body background="../Include/Img/background.gif" style="background-size:cover;" bgcolor="#0099ff">
<?php 
@session_start(); 
$_SESSION['s'];
$_SESSION['p']; 
if(isset($_SESSION['s_date'])||isset($_SESSION['e_date'])||isset($_SESSION['ph_no']))
{
	$s_date=$_SESSION['s_date'];
	$e_date=$_SESSION['e_date'];
	$ph_no=$_SESSION['ph_no'];
}
require_once '../Include/auth.php';
require_once '../Include/connect.php';
require_once '../Include/header.php';
$display=4;
if(isset($_GET['s'])&&is_numeric($_GET['s']))
{
	$S=$_GET['s']; //to be used in case of refreshing the page on demand
	$_SESSION['s']=$_GET['s']; //used in case of deletion
}
if(isset($_GET['p'])&&is_numeric($_GET['p']))
{
	$pages=$_GET['p'];
	$P=$_GET['p']; //to be used in case of refreshing the page on demand
	$_SESSION['p']=$_GET['p']; //used in case of deletion
}
else 
{
	if(isset($_POST['find_date'])&&isset($_POST['s_date'])&&isset($_POST['e_date']))
	{
		$s_date=$_POST['s_date'];
		$e_date=$_POST['e_date'];
		$q="select * from applicant where (d_o_e between '$s_date' and '$e_date')";
	}
	if(isset($_POST['find_mobile'])&&isset($_POST['s_ph_no'])&&isset($_POST['e_ph_no']))
	{
		$s_ph_no=$_POST['s_ph_no'];
		$e_ph_no=$_POST['e_ph_no'];
		$q="select * from applicant where (ph_no between '$s_ph_no' and '$e_ph_no')";
	}
	if(isset($_POST['find_phone'])&&isset($_POST['ph_no']))
	{
		$ph_no=$_POST['ph_no'];
		$q="select * from applicant where ph_no=$ph_no";
	}
	$r=mysql_query($q,$link);
	$records=@mysql_num_rows($r);
	if($records>$display)
	{
		$pages=ceil($records/$display);
	}
	else 
	{
		$pages=1;	
	}
}
if(isset($_GET['s'])&&is_numeric($_GET['s']))
{
	$start=$_GET['s'];
}
else 
{
	$start=0;
}
echo "<b><center style='color: #003300;'><h2><u>SEARCH AND START OVER ANY TASK</u></h2></center></b>";
echo "<form method='post'  action='find_app.php'>";
echo "<table bgcolor='#066ff' width='100%'>";
echo "<tr><td></td><td><b>Date From</b></td><td><input type='text' size='9' id='CalendarValue' name='s_date' value='$s_date'>
        		         <a href=''><img id='CalendarButton' src='../Include/Img/cal.gif' onclick=\"CalendarClick(event)\"></a>
                     </td><td><b>To</b></td>
                     <td><input type='text' size='9' id='CalendarValue1' name='e_date' value='$e_date'>
        		         <a href=''><img id='CalendarButton1' src='../Include/Img/cal.gif' onclick=\"calendar(event)\"></a>
                     </td>
                     <td><input id='find' type='submit' name='find_date' value=''></td><td>&nbsp;</td>";
echo "</form>";
echo "<form method='post' action='find_app.php'>";
echo "<td><b>Record No </b></td>&nbsp;<td> <input type='text' size='10' name='s_ph_no' value=''></td>";
echo "<td><b>To</b></td> &nbsp;<td><input type='text' size='10' name='e_ph_no' value=''></td>";
echo "<td><input id='find' type='submit' name='find_mobile' value=''></td>";
echo "</form>";
echo "<form method='post' action='find_app.php'>";
echo "<td><b>Phone/Rec No</b></td> &nbsp;<td><input type='text' size='10' name='ph_no' value=''></td>";
echo "<td><input id='find' type='submit' name='find_phone' value=''></td></tr>";
echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
      <td color='red'><a href='find_app.php?s=$S&p=$P'><h3>Refresh</h3></a></td>";
echo "<td color='red'><a href='sessiondestroy.php'><h3>Reset</h3></a></td>";
echo "<td color='red'><a href='close_find.php'><h3>Close</h3></a></td></tr>";
echo "</table>";
echo "</form>";
if(isset($_POST['find_mobile'])&&isset($_POST['s_ph_no'])&&isset($_POST['e_ph_no']))
{
	$_SESSION['s_ph_no']=$_POST['s_ph_no'];
	$_SESSION['e_ph_no']=$_POST['e_ph_no'];
}
if(isset($_POST['find_phone'])&&isset($_POST['ph_no']))
{
	$_SESSION['ph_no']=$_POST['ph_no'];
}
if(isset($_POST['find_date'])&&isset($_POST['s_date'])&&isset($_POST['e_date']))
{
	$_SESSION['s_date']=$_POST['s_date'];
	$_SESSION['e_date']=$_POST['e_date'];
}
if(isset($_SESSION['s_ph_no'])&&isset($_SESSION['e_ph_no']))
{
	$s_ph_no=$_SESSION['s_ph_no'];
	$e_ph_no=$_SESSION['e_ph_no'];
	$q="select * from applicant where (ph_no between '$s_ph_no' and '$e_ph_no') order by ph_no limit $start,$display";
	$r=mysql_query($q,$link);
}
if(isset($_SESSION['ph_no']))
{
	$ph_no=$_SESSION['ph_no'];
	$q="select * from applicant where ph_no=$ph_no limit $start,$display";
	$r=mysql_query($q,$link);
}
if(isset($_SESSION['s_date'])&&isset($_SESSION['e_date']))
{
	$s_date=$_SESSION['s_date'];
	$e_date=$_SESSION['e_date'];
	$q="select * from applicant where (d_o_e between '$s_date' and '$e_date') order by d_o_e limit $start,$display";
	$r=mysql_query($q,$link);
}
$s=$_SESSION['s']; //used in deletion
$p=$_SESSION['p']; //used in deletion
$num=@mysql_num_rows($r);
if($num>0)
{
while ($row=mysql_fetch_array($r))
{
$applicant_id=$row['applicant_id'];
$group_id=$row['group_id'];
$applicant_name=$row['applicant_name'];
$group_name=$row['group_name'];
$d_o_e=$row['d_o_e'];
$ph_no=$row['ph_no'];
$bill_status=$row['bill_status'];
$q1="select tm from scoring where applicant_id=$applicant_id";
$r1=mysql_query($q1,$link);
$row1=mysql_fetch_array($r1);
$tm=$row1['tm'];
if($group_id==1)
	echo "<br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Farmers Name : </b>$applicant_name";
if($group_id==2)
    echo "<br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;S.H.G Name  :  </b>$group_name";
if($group_id==3)
    echo "<br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;A.S.G Name   : </b>$group_name";
echo "<br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date of Entry  : </b>$d_o_e";
if($ph_no!=0)
    echo "<br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phone/Record No  : </b>$ph_no";
echo "<br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total Marks     : </b>$tm";
echo "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input id='edit_applicant' type='button' value='' onclick=\"Javascript:window.open('../Applicant/applicant_edit.php?applicant_id=$applicant_id&group_id=$group_id')\">";
echo "&nbsp;&nbsp;&nbsp;<input id='delete_applicant' type='button' value='' onclick=\"Javascript:applicant_delete('$applicant_id','$s','$p')\">";
if($bill_status==0)
echo "&nbsp;&nbsp;&nbsp;<input id='create_bill' type='button' value='' onclick=\"Javascript:window.open('../Billing/bill_info.php?applicant_id=$applicant_id')\">";
else 
{
echo "&nbsp;&nbsp;&nbsp;<input id='edit_bill' type='button' value='' onclick=\"Javascript:window.open('../Billing/bill_info.php?applicant_id=$applicant_id')\">";
echo "&nbsp;&nbsp;&nbsp;<input id='delete_bill' type='button' value='' onclick=\"Javascript:delete_bill('$applicant_id','$s','$p')\">";

echo "&nbsp;&nbsp;&nbsp;<input id='view_bill' type='button' value='' onclick=\"Javascript:window.open('../Billing/report.php?applicant_id=$applicant_id')\">";
}
echo "<br>";
}
}
if($pages>1)
{
	echo "<table align='center'>";
	$current_page=($start/$display)+1;
	if($current_page!=1)
	{
		$prev=$start-$display;
		echo "<tr><td><a href='find_app.php?s=$prev&p=$pages'>Previous</a></td>";
	}
	for($i=1;$i<=$pages;$i++)
	{
		if($i!=$current_page)
		{    
			$d=$display*($i-1);
			//echo "<td><a href='find_app.php?s=$d&p=$pages'>$i</a></td>";
		}
		else 
		{
			echo "<td>Page $i</td>";
		}
	}
	if($current_page!=$pages)
	{
		$n=$start+$display;
		echo "<td><a href='find_app.php?s=$n&p=$pages'>Next</a></td></tr>";
	}
	echo "</table>";
}

?>
</body>
</html>