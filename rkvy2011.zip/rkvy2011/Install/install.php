<?php
/*=========================================
  Author : Ruhul Amin Khan.
  Installation script for RKVY 2011
  =========================================
*/       
$DB_HOST=$_POST['db_host'];
$DB_USER=$_POST['db_user'];
$DB_PASSWORD=$_POST['db_password'];
$DB_DATABASE=$_POST['db_database'];
$admin_username=$_POST['admin_username'];
$admin_password=$_POST['admin_password'];
//saving configuration data in a file
$settings = "<?php\n";
$settings .= "define('DB_HOST','$DB_HOST');\n";
$settings .= "define('DB_USER','$DB_USER');\n";
$settings .= "define('DB_PASSWORD','$DB_PASSWORD');\n";
$settings .= "define('DB_DATABASE','$DB_DATABASE');\n";
$settings .= "?>\n";
$fd = fopen( '../Include/config.php', "w" )
or die ("Cannot create configuration file.");
fwrite( $fd, $settings );
fclose( $fd );
//automatically creating database schema and inserting necessary items in tables
$link = mysql_connect($DB_HOST, $DB_USER, $DB_PASSWORD);
	if(!$link) {
		die('Failed to connect to server: ' . mysql_error());
	}
mysql_query("CREATE DATABASE $DB_DATABASE");
$db = mysql_select_db($DB_DATABASE);
	if(!$db) {
		die("Unable to select database");
	}
$q="CREATE TABLE applicant (
applicant_id int(12) unsigned NOT NULL auto_increment,
applicant_name varchar(50),
group_id int(1) NOT NULL default 0,
group_name varchar(30),
n_o_group int(3) NOT NULL default 0,
d_o_e date NOT NULL,
vill varchar(30) NOT NULL,
po varchar(30) NOT NULL,
gp varchar(30) NOT NULL,
ap varchar(30) NOT NULL,
zp varchar(30) NOT NULL,
block varchar(30) NOT NULL,
sub_division varchar(30),
t_land varchar(30) NOT NULL,
c_land varchar(30) NOT NULL,
n_o_m varchar(30) NOT NULL,
n_o_m_o int(3) NOT NULL default 0,
ph_no bigint NOT NULL,
grant_date date,
pump_a_date date,
pump_back_date date,
fir_status int(1) NOT NULL default 0,
fir_date date,
reason blob,
bill_status int(1) default 0,
UNIQUE(ph_no),
PRIMARY KEY(applicant_id)
)TYPE=MyISAM";
mysql_query($q,$link);

$q="CREATE TABLE scoring(
applicant_id int(12) NOT NULL,
w_c_f_s int(1) NOT NULL default 0,
is_defaulter int(1) NOT NULL default 0,
i_f int(1) NOT NULL default 0,
w_section int(3) NOT NULL default 0,
n_o_w_f int(3) NOT NULL default 0,
f_used int(1) NOT NULL default 0,
c_intensity int(4) NOT NULL default 0,
bank_amount decimal(12,2) NOT NULL default 0,
tm int(8) NOT NULL default 0,
UNIQUE(applicant_id)
)TYPE=MyISAM";
mysql_query($q,$link);

$q="CREATE TABLE bill_info(
applicant_id int(12) NOT NULL,
w_o_n varchar(30) default 'NA',
w_o_date date default '0000-00-00',
d_o_c date default '0000-00-00',
depth decimal(5,2) default 0,
mb_no varchar(30) default 'NA',
page_s decimal(3) NOT NULL default 0,
page_e decimal(3) NOT NULL default 0,
v_bill_no varchar(30) default 'NA',
d_o_b date default '0000-00-00',
m_s_p varchar(30) default 'NA',
memo_no varchar(30) default 'NA',
d_o_memo date default '0000-00-00',
m_s_m varchar(30) default 'NA',
UNIQUE(applicant_id)
)TYPE=MyISAM";
mysql_query($q,$link);

$q="CREATE TABLE item_table(
item_no int(8) unsigned NOT NULL auto_increment,
item_name varchar(255) NOT NULL,
cat_id int(1) NOT NULL default 0,
price decimal(12,2) NOT NULL,
brand varchar(30),
model varchar(30),
hp varchar(3),
PRIMARY KEY(item_no)
)TYPE=MyISAM";
mysql_query($q,$link);

$q="CREATE TABLE material_cost(
id int(12) unsigned NOT NULL auto_increment,
item_name varchar(255) NOT NULL,
quantity int(8) NOT NULL,
rate decimal(12,2) NOT NULL,
amount decimal(12,2) NOT NULL,
applicant_id int(12) NOT NULL,
PRIMARY KEY(id)
)TYPE=MyISAM";
mysql_query($q,$link);

$q="CREATE TABLE install_cost(
id int(12) unsigned NOT NULL auto_increment,
item_name varchar(255) NOT NULL,
quantity int(8) NOT NULL,
rate decimal(12,2) NOT NULL,
amount decimal(12,2) NOT NULL,
applicant_id int(12) NOT NULL,
PRIMARY KEY(id)
)TYPE=MyISAM";
mysql_query($q,$link);

$q="CREATE TABLE pump_cost(
id int(12) unsigned NOT NULL auto_increment,
item_name varchar(255) NOT NULL,
quantity int(8) NOT NULL,
rate decimal(12,2) NOT NULL,
amount decimal(12,2) NOT NULL,
applicant_id int(8) NOT NULL,
PRIMARY KEY(id)
)TYPE=MyISAM";
mysql_query($q,$link);

$q="CREATE TABLE sum_cost(
id int(12) unsigned NOT NULL auto_increment,
mat_cost decimal(12,2) NOT NULL default 0,
install_cost decimal(12,2) NOT NULL default 0,
pump_cost decimal(12,2) NOT NULL default 0,
tc decimal(12,2) NOT NULL default 0,
gs decimal(12,2) NOT NULL default 0,
fs decimal(12,2) NOT NULL default 0,
applicant_id int(12) NOT NULL,
PRIMARY KEY(id),
UNIQUE(applicant_id)
)TYPE=MyISAM";
mysql_query($q,$link);

$q="CREATE TABLE members(
member_id int(8) unsigned NOT NULL auto_increment,
firstname varchar(20) NOT NULL,
lastname varchar(20),
login varchar(20) NOT NULL,
passwd varchar(32) NOT NULL,
reg_date datetime NOT NULL,
PRIMARY KEY(member_id),
UNIQUE(login)
)TYPE=MyISAM";
mysql_query($q,$link);
$q="INSERT INTO members(firstname, lastname, login, passwd, reg_date) VALUES('Administrator','','$admin_username', md5('$admin_password'), NOW())";
mysql_query($q,$link);
$q="INSERT INTO item_table (item_name, cat_id, price, brand, model, hp) VALUES
('Ashok Engineering & Foundry Works, Rajkot', 3, 18690.00, 'Usha', 'ULD-4000', '4'),
('Kirloskar Oil Engine Ltd', 3, 26424.00, 'Kirloskar', 'AV1 XLN1', '5'),
('Greaves Cotton Ltd, Thapar house, Kolkata', 3, 24938.00, 'Greaves', '5520', '5'),
('Greaves Cotton Ltd, Thapar house, Kolkata', 3, 28949.00, 'Greaves', 'GWP-5', '5'),
('Gurat Forging Ltd, Rajkot', 3, 24110.00, 'Field Marshal', 'GF-50M', '5'),
('Gurat Forging Ltd, Rajkot', 3, 23090.00, 'Field Marshal', 'GF-50MP', '5'),
('Ashok Engineering & Foundry Works, Rajkot', 3, 19761.00, 'Usha', 'ULD-5000', '5'),
('Ashok Engineering & Foundry Works, Rajkot', 3, 28928.00, 'Usha', 'USHA-500', '5'),
('Rocket Engineering Corporation Pvt. Ltd, Kolhapur', 3, 27615.00, 'Usha', 'USHA-URW/MFA', '5'),
('Rocket Engineering Corporation Pvt. Ltd, Kolhapur', 3, 27615.00, 'Comet', 'CPW-5', '5'),
('Rocket Engineering Corporation, Pvt. Ltd, Kolhapur', 3, 27615.00, 'Comet', 'PPW-5A', '5'),
('Chandra Metal Enterprise, Agra', 3, 29127.00, 'CROWN', 'EN-CV1,Pm-Jindal', '5'),
('Prakash Agricultural Industries', 3, 24290.00, 'SWARAJ', 'MPV-5', '5'),
('Prakash Agricultural Industries', 3, 24025.00, 'SWARAJ', 'PV-1', '4.5'),
('Prakash Agricultural Industries', 3, 25865.00, 'SWARAJ', 'PV-5', '5'),
('Lubi Submersibles Ltd, Ahmedabad', 3, 19320.00, 'Lubi', 'LS-40L', '4'),
('Lubi Submersibles Ltd, Ahmedabad', 3, 26376.00, 'Lubi', 'LS-45', '5'),
('Lubi Submersibles Ltd, Ahmedabad', 3, 29085.00, 'Lubi', 'LS-50', '5'),
('Parshva Diesels Pvt. Ltd', 3, 28350.00, 'ALFA', 'WK-3', '5'),
('Light duty G.I Pipe of 80mm Dia, BIS-1239', 1, 255.00, '', '', ''),
('PVC Pipe of 90mm Dia, BIS-4985', 1, 115.00, '', '', ''),
('PVC Ribbed Screen Strainer of 90mm Dia ', 1, 215.00, '', '', ''),
('Hand Tube Well head, No.6', 1, 680.00, '', '', ''),
('Combined Special Tee, (80X40X80)mm', 1, 150.00, '', '', ''),
('End plug 90mm Dia', 1, 40.00, '', '', ''),
('PVC Suction Pipe, 80mm Dia', 1, 103.00, '', '', ''),
('PVC Male Thread Adaptor', 1, 30.00, '', '', ''),
('GI Nipple (150X40)mm', 1, 30.00, '', '', ''),
('PVC Socket', 1, 25.00, '', '', ''),
('Solvent cement', 1, 25.00, '', '', ''),
('Labour charge for developing, lowering, shrounding etc', 2, 200.00, '', '', ''),
('Cost of Pebbles', 2, 170.00, '', '', ''),
('Labour Charge for boring upto _______ Mtr. depth and 150 cm dia complete as directed inclusive of collection of samples etc.', 2, 85.00, '', '', '');
";
$final=mysql_query($q,$link);
if($final)
//header("location: ../Login/login.php");
echo "<script language='javascript'> window.location.href='../Login/login.php'</script>";
?>