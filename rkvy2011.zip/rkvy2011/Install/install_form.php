<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Installation Details</title>
<link href="loginmodule.css" rel="stylesheet" type="text/css" />
</head>
<body bgcolor="#0099ff">
<h1 align="center">Installation data for R.K.V.Y 2011</h1><br />
<p>&nbsp;</p>
<form  name="Installation From" method="post" action="install.php">
  <table width="300" border="0" align="center" cellpadding="2" cellspacing="0">
    <tr>
      <td width="112"><b>Database Host Name</b></td>
      <td width="188"><input name="db_host" type="text" class="textfield" id="login" /></td>
    </tr>
    <tr>
      <td><b>Database Username</b></td>
      <td><input name="db_user" type="text" class="textfield" id="login" /></td>
    </tr>
    <tr>
      <td><b>Database Password</b></td>
      <td><input name="db_password" type="password" class="textfield" id="password" /></td>
    </tr>
    <tr>
      <td><b>Retype Password</b></td>
      <td><input name="db_password1" type="password" class="textfield" id="password" /></td>
    </tr>
    <tr>
      <td><b>Database Name</b></td>
      <td><input name="db_database" type="text" class="textfield" id="login" /></td>
    </tr>
    <tr>
      <td><b>Administrator Login Id</b></td>
      <td><input name="admin_username" type="text" class="textfield" id="login" /></td>
    </tr>
    <tr>
      <td><b>Administrator Password</b></td>
      <td><input name="admin_password" type="password" class="textfield" id="password" /></td>
    </tr>
    <tr>
      <td><b>Retype Password</b></td>
      <td><input name="db_password1" type="password" class="textfield" id="password" /></td>
    </tr>
    <tr>
      <td>&nbsp; </td>
      <td><input type="submit" name="Submit" value="Install" /></td>
    </tr>
  </table>
</form>
</body>
</html>
