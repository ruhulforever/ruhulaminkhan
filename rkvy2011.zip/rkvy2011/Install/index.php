<?php
//header("location:install_form.php");
echo "<script language='javascript'> window.location.href='install_form.php'</script>";
?>