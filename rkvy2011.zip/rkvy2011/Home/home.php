<html>
<head>
<meta http-equiv="refresh" content="30; url=home.php">
<title>Information System For R.K.V.Y.2011</title>
<link href="../Include/rkvy.css" rel="StyleSheet" type="text/css">
<script src="../Include/about.js" type="text/javascript"></script>
</head>
<body background="../Include/Img/background.gif" style="background-size: cover;" bgcolor="#0099ff">
<?php 
require_once '../Include/auth.php';
require_once '../Include/main.php';
require_once '../Include/header.php';
require_once '../Include/connect.php';
$firstname=$_SESSION['firstname'];
$lastname=$_SESSION['lastname'];
echo "<div id='refresh'>";
$q1="select count(group_id) as individual from applicant where group_id=1"; // total individual
$q2="select count(group_id) as shg from applicant where group_id=2"; //total S.H.G
$q3="select count(group_id) as asg from applicant where group_id=3"; //total A.S.G
$q4="select max(tm) as tm from scoring"; //highest total mark
$q5="select count(fir_status) as fir from applicant where fir_status=1"; //total exceptional conditions
$q6="select count(bill_status) as bill from applicant where bill_status=1"; //total bill prepared
$r1=mysql_query($q1,$link);
$r2=mysql_query($q2,$link);
$r3=mysql_query($q3,$link);
$r4=mysql_query($q4,$link);
$r5=mysql_query($q5,$link);
$r6=mysql_query($q6,$link);
$individual=mysql_fetch_array($r1);
$shg=mysql_fetch_array($r2);
$asg=mysql_fetch_array($r3);
$tm=mysql_fetch_array($r4);
$fir=mysql_fetch_array($r5);
$bill=mysql_fetch_array($r6);
$total_app=$individual[individual]+$shg[shg]+$asg[asg];
echo "<div style='color: #003300;'><b>Welcome $firstname $lastname !</b></div>
      <div style='color: #003300;' align='right'><b><a href='../Login/c_password.php'>Change Password</a></b></div>";
echo "<center><img src='../Include/Img/title.gif' style='opacity:0.9;' alt='OFFICE OF THE EXECUTIVE ENGINEER (AGRI), SONITPUR ASSAM'/></center>";
echo "<br><center><b><font color='#003300'><marquee width='50%'>Current Status of The System</marquee></b></center>";
echo "<br><table align='center' border='1'>";
       echo "<tr><td><b>Total No. of Applicant (Including S.H.G, A.S.G & Individual) </b></td><td align='center' width='60'><b>$total_app</b></td></tr>";
       echo "<tr ><td><b>Total No. of S.H.G </b></td><td align='center'><b>$shg[shg]</b></td></tr>";
       echo "<tr><td><b>Total No. of A.S.G </b></td><td align='center'><b>$asg[asg]</b></td></tr>";
       echo "<tr ><td><b>Total No. of Individual Applicant</b></td><td align='center'><b>$individual[individual]</b></td></tr>";
       echo "<tr><td><b>Highest Mark Gained </b></td><td align='center'><b>$tm[tm]</b></td></tr>";
       echo "<tr><td><b>Total Bill Prepared </b></td><td align='center'><b>$bill[bill]</b></td></tr>";
       //echo "<tr ><td><b>Total Complaints For Exceptions </b></td><td align='center'><b>$fir[fir]</b></td></tr>";
       echo "</table>";
echo "</div>";
?>
</body>
</html>